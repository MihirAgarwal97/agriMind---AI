"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { ArrowRight, Zap, Play, ChevronDown, Sprout, CloudRain, Bug, TrendingUp, Brain, Check } from "lucide-react";
import { SectionTitle } from "@/components/ui/SharedComponents";

const AgriCanvas = dynamic(() => import("@/components/ai/AgriCanvas"), { ssr: false });

const HERO_WORDS = ["Every Acre.", "Every Crop.", "Every Decision.", "Your Farm."];

function HeroSection() {
  const [wordIndex, setWordIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setWordIndex((prev) => (prev + 1) % HERO_WORDS.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background ambient */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-hero-mesh" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-forest-900/20 rounded-full blur-[120px] animate-pulse" style={{ animationDuration: "4s" }} />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-emerald-900/15 rounded-full blur-[80px] animate-pulse" style={{ animationDuration: "6s" }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[calc(100vh-5rem)]">

          {/* Left: Text content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex flex-col gap-6"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 w-fit px-3 py-1.5 rounded-full border border-forest-700/60 bg-forest-900/40 backdrop-blur-sm"
            >
              <span className="w-2 h-2 rounded-full bg-forest-400 animate-pulse" />
              <span className="text-forest-400 text-sm font-medium">Hackathon Demo — IBM Granite + Multi-Agent AI</span>
            </motion.div>

            {/* Main headline */}
            <div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-5xl md:text-6xl lg:text-7xl font-black leading-[1.05] tracking-tight"
              >
                <span className="text-white">Intelligence for</span>
                <br />
                <AnimatePresence mode="wait">
                  <motion.span
                    key={wordIndex}
                    initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
                    animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                    exit={{ opacity: 0, y: -20, filter: "blur(8px)" }}
                    transition={{ duration: 0.4 }}
                    className="text-glow"
                    style={{ color: "#22c55e" }}
                  >
                    {HERO_WORDS[wordIndex]}
                  </motion.span>
                </AnimatePresence>
              </motion.div>
            </div>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-gray-400 text-lg md:text-xl leading-relaxed max-w-xl"
            >
              Your AI-powered farming copilot for smarter crops, healthier fields and better
              decisions — powered by{" "}
              <span className="text-blue-400 font-medium">IBM Granite</span> and{" "}
              <span className="text-forest-400 font-medium">multi-agent intelligence</span>.
            </motion.p>

            {/* CTAs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap gap-4"
            >
              <Link
                href="/analyze"
                className="group flex items-center gap-3 px-6 py-3.5 rounded-xl bg-forest-600 hover:bg-forest-500 text-white font-semibold text-base transition-all duration-200 shadow-xl shadow-forest-900/40 hover:shadow-forest-500/30 hover:-translate-y-0.5"
              >
                <Zap className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                Analyze My Farm
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/agents"
                className="flex items-center gap-3 px-6 py-3.5 rounded-xl border border-forest-700/60 bg-forest-900/30 hover:bg-forest-900/60 text-forest-300 hover:text-forest-200 font-semibold text-base transition-all duration-200"
              >
                <Play className="w-4 h-4" />
                Explore AI Agents
              </Link>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex gap-8 pt-2"
            >
              {[
                { label: "AI Agents", value: "4" },
                { label: "Knowledge Articles", value: "8+" },
                { label: "Decision Points", value: "35+" },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-2xl font-bold text-forest-400">{stat.value}</div>
                  <div className="text-xs text-gray-500 mt-0.5">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right: Canvas visualization */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="relative h-[500px] lg:h-[580px] rounded-3xl overflow-hidden border border-forest-900/40"
            style={{ background: "rgba(7,26,14,0.3)" }}
          >
            <AgriCanvas />
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-center">
              <div className="flex items-center gap-2 px-4 py-2 rounded-full glass text-xs text-gray-400">
                <span className="w-1.5 h-1.5 rounded-full bg-forest-400 animate-pulse" />
                Live AI Agent Network — hover to interact
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <ChevronDown className="w-6 h-6 text-gray-600" />
      </motion.div>
    </section>
  );
}

function TechStrip() {
  const techs = [
    { name: "IBM Granite", desc: "Foundation Model", color: "text-blue-400", border: "border-blue-500/30", bg: "bg-blue-500/10" },
    { name: "IBM Bob Agent", desc: "AI Orchestration", color: "text-indigo-400", border: "border-indigo-500/30", bg: "bg-indigo-500/10" },
    { name: "RAG Architecture", desc: "Knowledge Retrieval", color: "text-forest-400", border: "border-forest-500/30", bg: "bg-forest-500/10" },
    { name: "Multi-Agent AI", desc: "4 Specialized Agents", color: "text-emerald-400", border: "border-emerald-500/30", bg: "bg-emerald-500/10" },
  ];

  return (
    <section className="py-12 border-y border-forest-900/40">
      <div className="max-w-7xl mx-auto px-4">
        <p className="text-center text-xs text-gray-600 mb-6 uppercase tracking-widest font-medium">
          Powered By
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          {techs.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`flex items-center gap-3 px-5 py-3 rounded-xl border ${t.border} ${t.bg}`}
            >
              <div>
                <div className={`text-sm font-bold ${t.color}`}>{t.name}</div>
                <div className="text-xs text-gray-500">{t.desc}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProblemSection() {
  const problems = [
    { icon: "🌱", title: "Crop Health", desc: "Nutrient, water, and growth status require constant monitoring and expertise." },
    { icon: "🌦", title: "Weather", desc: "Changing weather patterns affect irrigation, spray timing, and pest pressure." },
    { icon: "🐛", title: "Disease & Pest", desc: "Early detection of disease and pests can save an entire crop season." },
    { icon: "💰", title: "Market", desc: "Harvest timing and market conditions directly affect farm profitability." },
  ];

  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <SectionTitle
          badge="Why AgriMind?"
          title="Farming Decisions Are Connected."
          subtitle="A single decision affects your entire farm. One wrong call on irrigation, nutrition, or timing can cascade into lost yield and profit."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          {/* Connection lines SVG overlay */}
          <div className="absolute inset-0 hidden lg:block pointer-events-none">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              <path d="M 25 50 Q 50 30 75 50" stroke="rgba(34,197,94,0.15)" strokeWidth="0.5" fill="none" strokeDasharray="2 2" />
              <path d="M 25 50 Q 50 70 75 50" stroke="rgba(34,197,94,0.1)" strokeWidth="0.5" fill="none" strokeDasharray="2 2" />
            </svg>
          </div>

          {problems.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative p-6 rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/60 card-hover group"
            >
              <div className="text-3xl mb-4">{p.icon}</div>
              <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-forest-300 transition-colors">{p.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{p.desc}</p>
              <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-forest-600/50 group-hover:bg-forest-400 transition-colors" />
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-8 text-center text-forest-400 font-medium text-sm"
        >
          AgriMind AI connects all four domains into one intelligent decision engine ↑
        </motion.div>
      </div>
    </section>
  );
}

function AgentsSection() {
  const agents = [
    {
      icon: "🌱",
      title: "Crop Intelligence Agent",
      color: "from-forest-900/80 to-forest-950/80",
      border: "border-forest-700/30",
      glow: "hover:border-forest-500/50 hover:shadow-forest-500/10",
      capabilities: ["Crop stage analysis", "Soil context assessment", "Nutrition requirements", "Growth monitoring"],
      model: "Granite + Crop KB",
    },
    {
      icon: "🌦",
      title: "Weather & Irrigation Agent",
      color: "from-sky-900/50 to-sky-950/80",
      border: "border-sky-700/30",
      glow: "hover:border-sky-500/50 hover:shadow-sky-500/10",
      capabilities: ["Weather pattern analysis", "Irrigation scheduling", "Temperature monitoring", "Rain forecasting"],
      model: "Granite + Weather KB",
    },
    {
      icon: "🐛",
      title: "Pest & Disease Agent",
      color: "from-orange-900/40 to-orange-950/80",
      border: "border-orange-700/30",
      glow: "hover:border-orange-500/50 hover:shadow-orange-500/10",
      capabilities: ["Symptom analysis", "Disease identification", "Pest risk assessment", "Treatment guidance"],
      model: "Granite + Disease KB",
    },
    {
      icon: "💰",
      title: "Market Intelligence Agent",
      color: "from-purple-900/40 to-purple-950/80",
      border: "border-purple-700/30",
      glow: "hover:border-purple-500/50 hover:shadow-purple-500/10",
      capabilities: ["Market trend analysis", "Harvest timing", "Cost optimization", "Revenue projection"],
      model: "Granite + Market KB",
    },
  ];

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-transparent to-forest-950/20">
      <div className="max-w-6xl mx-auto">
        <SectionTitle
          badge="Multi-Agent Architecture"
          title="Four AI Experts. One Farming Brain."
          subtitle="Each specialist agent analyzes a different dimension of your farm. IBM Granite synthesizes their findings into actionable recommendations."
        />

        {/* IBM Granite center */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="flex justify-center mb-8"
        >
          <div className="flex items-center gap-3 px-6 py-3 rounded-2xl border border-blue-500/40 bg-blue-500/10 backdrop-blur-sm">
            <Brain className="w-5 h-5 text-blue-400" />
            <span className="text-blue-300 font-semibold text-sm">IBM Granite Intelligence — Central Synthesis Engine</span>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {agents.map((agent, i) => (
            <motion.div
              key={agent.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -6 }}
              className={`p-6 rounded-2xl border ${agent.border} bg-gradient-to-br ${agent.color} ${agent.glow} transition-all duration-300 hover:shadow-xl`}
            >
              <div className="text-3xl mb-3">{agent.icon}</div>
              <h3 className="text-sm font-bold text-white mb-3 leading-tight">{agent.title}</h3>
              <ul className="space-y-1.5 mb-4">
                {agent.capabilities.map((cap) => (
                  <li key={cap} className="flex items-center gap-2 text-xs text-gray-400">
                    <Check className="w-3 h-3 text-forest-500 flex-shrink-0" />
                    {cap}
                  </li>
                ))}
              </ul>
              <div className="text-xs text-gray-600 border-t border-white/5 pt-3 font-mono">
                {agent.model}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <Link
            href="/analyze"
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-forest-600 hover:bg-forest-500 text-white font-semibold text-base transition-all duration-200 shadow-xl shadow-forest-900/40 hover:-translate-y-0.5"
          >
            <Zap className="w-5 h-5" />
            Start Farm Analysis
            <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

export default function HomePage() {
  return (
    <main>
      <HeroSection />
      <TechStrip />
      <ProblemSection />
      <AgentsSection />
    </main>
  );
}
