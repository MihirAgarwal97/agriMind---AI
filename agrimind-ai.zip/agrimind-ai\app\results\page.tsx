"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import {
  Sprout, Droplets, Bug, CloudRain, TrendingUp, Brain, ChevronDown,
  ChevronUp, BookOpen, ArrowRight, Calendar, AlertTriangle, CheckCircle2, Zap
} from "lucide-react";
import { ScoreGauge, StatusBadge, DemoBadge } from "@/components/ui/SharedComponents";
import { DEMO_ANALYSIS_RESULT } from "@/lib/demo/demoData";
import { getScoreColor, getPriorityColor, getCategoryIcon } from "@/lib/utils";
import type { AnalysisResult } from "@/lib/types";

export default function ResultsPage() {
  const [result, setResult] = useState<AnalysisResult>(DEMO_ANALYSIS_RESULT as AnalysisResult);
  const [showEvidence, setShowEvidence] = useState(false);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<"overview" | "agents" | "plan">("overview");

  useEffect(() => {
    try {
      const stored = sessionStorage.getItem("agrimind_result");
      if (stored) {
        const parsed = JSON.parse(stored);
        setResult(parsed);
      }
    } catch {}
  }, []);

  const { scores, agentResponses, graniteSynthesis, actionPlan, weatherForecast } = result;

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <h1 className="text-3xl font-bold text-white">Farm Intelligence Report</h1>
                <DemoBadge />
              </div>
              <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                <span>📍 {result.location}</span>
                <span>🌱 {result.crop}</span>
                <span>📐 {result.farmSize}</span>
                <span>⏱ {result.cropAge}</span>
              </div>
            </div>
            <div className="flex gap-3">
              <Link
                href="/analyze"
                className="flex items-center gap-2 px-4 py-2 rounded-lg border border-forest-800/50 text-forest-400 hover:text-forest-300 text-sm transition-colors"
              >
                New Analysis
              </Link>
              <Link
                href="/dashboard"
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-forest-600 text-white text-sm font-medium hover:bg-forest-500 transition-colors"
              >
                <Zap className="w-4 h-4" />
                Dashboard
              </Link>
            </div>
          </div>
        </motion.div>

        {/* Score cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
          {[
            { label: "Crop Health", value: `${scores.cropHealth}/100`, score: scores.cropHealth, icon: "🌱", isNum: true },
            { label: "Water Status", value: scores.waterStatus, icon: "💧", isNum: false },
            { label: "Disease Risk", value: scores.diseaseRisk, icon: "🐛", isNum: false },
            { label: "Weather Risk", value: scores.weatherRisk, icon: "🌦", isNum: false },
            { label: "Market", value: scores.marketOpportunity, icon: "💰", isNum: false },
          ].map((card, i) => (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="rounded-xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/70 to-[#071a0e]/70 p-4 text-center"
            >
              <div className="text-2xl mb-2">{card.icon}</div>
              {card.isNum ? (
                <ScoreGauge score={card.score!} label={card.label} size={72} />
              ) : (
                <div>
                  <StatusBadge status={card.value} />
                  <div className="text-xs text-gray-500 mt-1.5">{card.label}</div>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-forest-900/40">
          {(["overview", "agents", "plan"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2.5 text-sm font-medium capitalize transition-colors border-b-2 -mb-px ${
                activeTab === tab
                  ? "border-forest-500 text-forest-400"
                  : "border-transparent text-gray-500 hover:text-gray-300"
              }`}
            >
              {tab === "overview" ? "AI Summary" : tab === "agents" ? "Agent Reports" : "7-Day Plan"}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* AI Executive Summary */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="rounded-2xl border border-blue-800/30 bg-gradient-to-br from-blue-900/20 to-blue-950/20 p-6"
            >
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-blue-400" />
                  <h3 className="font-bold text-white">AI Recommendation</h3>
                  <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/20">
                    IBM Granite
                  </span>
                </div>
                <div className="text-xs text-gray-500">
                  Confidence: {graniteSynthesis.confidence}%
                </div>
              </div>

              <p className="text-gray-300 leading-relaxed mb-4">
                {graniteSynthesis.summary}
              </p>

              <div className="flex flex-wrap gap-3 text-xs mb-4">
                <span className="px-2 py-1 rounded border border-orange-500/30 bg-orange-500/10 text-orange-400">
                  Risk: {graniteSynthesis.riskLevel}
                </span>
                <span className="px-2 py-1 rounded border border-yellow-500/30 bg-yellow-500/10 text-yellow-400">
                  {graniteSynthesis.urgency}
                </span>
              </div>

              <button
                onClick={() => setShowEvidence(!showEvidence)}
                className="flex items-center gap-2 text-blue-400 hover:text-blue-300 text-sm font-medium transition-colors"
              >
                <BookOpen className="w-4 h-4" />
                Why this recommendation?
                {showEvidence ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              <AnimatePresence>
                {showEvidence && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 pt-4 border-t border-blue-800/30"
                  >
                    <p className="text-xs text-gray-500 mb-3">
                      Recommendation supported by agricultural knowledge retrieved from the AgriMind RAG knowledge base:
                    </p>
                    <ul className="space-y-2">
                      {graniteSynthesis.evidenceSources.map((src, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm text-gray-400">
                          <CheckCircle2 className="w-3.5 h-3.5 text-forest-500 flex-shrink-0" />
                          {src}
                        </li>
                      ))}
                    </ul>
                    <p className="text-xs text-gray-600 mt-3 italic">
                      ⚠️ Always verify AI recommendations with qualified agricultural experts before acting.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Weather forecast */}
            <div className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/70 to-[#071a0e]/70 p-6">
              <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                <CloudRain className="w-4 h-4 text-sky-400" />
                7-Day Weather Outlook
                <DemoBadge />
              </h3>
              <div className="grid grid-cols-7 gap-2">
                {weatherForecast.map((day) => (
                  <div key={day.day} className="text-center">
                    <div className="text-xs text-gray-500 mb-1.5">{day.day}</div>
                    <div className="text-lg mb-1">
                      {day.icon === "sunny" ? "☀️" : day.icon === "rain" ? "🌧" : day.icon === "cloudy" ? "☁️" : "⛅"}
                    </div>
                    <div className="text-sm font-medium text-white">{day.temp}°</div>
                    <div className="text-xs text-sky-400">{day.rain}%</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Agents Tab */}
        {activeTab === "agents" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(agentResponses).map(([key, agent]) => {
              const icons: Record<string, React.ReactNode> = {
                crop: <Sprout className="w-4 h-4 text-forest-400" />,
                weather: <CloudRain className="w-4 h-4 text-sky-400" />,
                disease: <Bug className="w-4 h-4 text-orange-400" />,
                market: <TrendingUp className="w-4 h-4 text-purple-400" />,
              };
              const borders: Record<string, string> = {
                crop: "border-forest-800/50",
                weather: "border-sky-800/50",
                disease: "border-orange-800/50",
                market: "border-purple-800/50",
              };
              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`rounded-2xl border ${borders[key]} bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-5`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {icons[key]}
                      <span className="font-semibold text-white text-sm">{agent.agent}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <StatusBadge status="Complete" />
                      <span className="text-xs text-gray-500">{agent.confidence}%</span>
                    </div>
                  </div>
                  <p className="text-gray-400 text-sm leading-relaxed mb-3">{agent.analysis}</p>
                  <ul className="space-y-1.5">
                    {agent.recommendations.slice(0, 3).map((r, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-gray-500">
                        <span className="text-forest-600 mt-0.5">→</span>
                        {r}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* 7-Day Plan Tab */}
        {activeTab === "plan" && (
          <div className="space-y-3">
            <p className="text-sm text-gray-500 mb-4">
              Click on any day to see detailed instructions.
            </p>
            {actionPlan.map((item) => (
              <motion.div
                key={item.day}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: item.day * 0.05 }}
              >
                <button
                  onClick={() => setSelectedDay(selectedDay === item.day ? null : item.day)}
                  className="w-full text-left rounded-xl border border-forest-900/50 bg-gradient-to-r from-[#0d2918]/60 to-transparent p-4 hover:border-forest-700/60 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-forest-900/60 border border-forest-800/50 flex items-center justify-center text-lg flex-shrink-0">
                      {getCategoryIcon(item.category)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-600 font-mono">Day {item.day}</span>
                        <span className={`text-xs px-1.5 py-0.5 rounded border ${getPriorityColor(item.priority)}`}>
                          {item.priority}
                        </span>
                      </div>
                      <h4 className="text-white font-semibold text-sm mt-0.5">{item.title}</h4>
                      <p className="text-gray-400 text-xs mt-0.5 truncate">{item.description}</p>
                    </div>
                    <ChevronDown
                      className={`w-4 h-4 text-gray-600 flex-shrink-0 transition-transform ${
                        selectedDay === item.day ? "rotate-180" : ""
                      }`}
                    />
                  </div>
                </button>
                <AnimatePresence>
                  {selectedDay === item.day && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="rounded-b-xl border-x border-b border-forest-800/30 bg-forest-950/30 px-4 py-3 -mt-1 ml-4">
                        <p className="text-sm text-gray-300">{item.details}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        )}

        {/* Bottom navigation */}
        <div className="mt-10 pt-6 border-t border-forest-900/40 flex flex-wrap gap-3 justify-center">
          <Link href="/weather" className="flex items-center gap-2 px-4 py-2 rounded-lg border border-sky-800/40 bg-sky-900/20 text-sky-400 text-sm hover:bg-sky-900/30 transition-colors">
            <CloudRain className="w-4 h-4" /> Weather & Irrigation
          </Link>
          <Link href="/disease" className="flex items-center gap-2 px-4 py-2 rounded-lg border border-orange-800/40 bg-orange-900/20 text-orange-400 text-sm hover:bg-orange-900/30 transition-colors">
            <Bug className="w-4 h-4" /> Disease Detection
          </Link>
          <Link href="/market" className="flex items-center gap-2 px-4 py-2 rounded-lg border border-purple-800/40 bg-purple-900/20 text-purple-400 text-sm hover:bg-purple-900/30 transition-colors">
            <TrendingUp className="w-4 h-4" /> Market Insights
          </Link>
          <Link href="/advisor" className="flex items-center gap-2 px-4 py-2 rounded-lg border border-forest-800/40 bg-forest-900/20 text-forest-400 text-sm hover:bg-forest-900/30 transition-colors">
            <Brain className="w-4 h-4" /> Ask AgriMind
          </Link>
        </div>
      </div>
    </div>
  );
}
