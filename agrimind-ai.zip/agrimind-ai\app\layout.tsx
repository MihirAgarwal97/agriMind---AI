import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/ui/Navbar";

export const metadata: Metadata = {
  title: "AgriMind AI — Intelligence for Every Acre",
  description:
    "AI-powered crop intelligence, weather insights, disease detection and market guidance — all working together to help farmers make better decisions.",
  keywords: "AI farming, crop intelligence, agricultural AI, IBM Granite, smart farming",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased min-h-screen bg-[#030b06] text-forest-50">
        <Navbar />
        {children}
      </body>
    </html>
  );
}
