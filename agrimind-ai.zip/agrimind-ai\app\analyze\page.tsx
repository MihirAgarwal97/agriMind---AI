"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import {
  MapPin, Wheat, AlertCircle, Target, ChevronRight, ChevronLeft,
  Upload, Zap, Leaf, Droplets, FlaskConical, BarChart3, Sprout
} from "lucide-react";
import { DEMO_FARM } from "@/lib/demo/demoData";
import type { FarmData } from "@/lib/types";

const STEPS = [
  { id: 1, title: "Farm Details", icon: MapPin, desc: "Location & field information" },
  { id: 2, title: "Crop Info", icon: Leaf, desc: "What are you growing?" },
  { id: 3, title: "Current Condition", icon: AlertCircle, desc: "Issues & observations" },
  { id: 4, title: "Goals", icon: Target, desc: "What do you want to achieve?" },
];

const SOIL_TYPES = ["Loamy", "Sandy", "Clay", "Silty", "Peaty", "Chalky", "Sandy Loam", "Clay Loam"];
const IRRIGATION_TYPES = ["Drip Irrigation", "Sprinkler", "Flood/Furrow", "Rain-fed", "Manual"];
const CROP_LIST = ["Tomato", "Wheat", "Rice", "Cotton", "Maize", "Soybean", "Sugarcane", "Potato", "Onion", "Mustard", "Chili", "Brinjal", "Cabbage", "Other"];
const GOALS = ["Increase Yield", "Reduce Cost", "Prevent Disease", "Save Water", "Improve Crop Health", "Organic Farming"];

const DEFAULT_FORM: FarmData = {
  location: "",
  farmSize: "",
  soilType: "",
  irrigationType: "",
  crop: "",
  cropVariety: "",
  cropAge: "",
  plantingDate: "",
  problem: "",
  leafColor: "",
  symptoms: "",
  recentWeather: "",
  notes: "",
  budget: "",
  expectedYield: "",
  primaryGoal: "",
  image: null,
};

export default function AnalyzePage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FarmData>(DEFAULT_FORM);
  const [dragOver, setDragOver] = useState(false);

  const update = (field: keyof FarmData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const loadDemo = () => {
    setForm({ ...DEMO_FARM, image: null });
    setStep(1);
  };

  const handleAnalyze = () => {
    // Store form data in session storage for results page
    sessionStorage.setItem("agrimind_farm_data", JSON.stringify(form));
    router.push("/analysis");
  };

  const isStepValid = (s: number) => {
    if (s === 1) return form.location.trim() !== "" && form.farmSize !== "" && form.soilType !== "";
    if (s === 2) return form.crop !== "" && form.cropAge !== "";
    if (s === 3) return true;
    if (s === 4) return true;
    return true;
  };

  const canProceed = isStepValid(step);

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      {/* Background */}
      <div className="fixed inset-0 bg-hero-mesh opacity-50 pointer-events-none" />

      <div className="relative max-w-3xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">Analyze Your Farm</h1>
          <p className="text-gray-400">
            Provide your farm details to receive an AI-powered intelligence report
          </p>
          <button
            onClick={loadDemo}
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-amber-500/40 bg-amber-500/10 text-amber-400 text-sm font-medium hover:bg-amber-500/20 transition-colors"
          >
            <Sprout className="w-4 h-4" />
            Load Demo Farm (Jaipur Tomato)
          </button>
        </motion.div>

        {/* Step indicator */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            const isActive = s.id === step;
            const isDone = s.id < step;
            return (
              <div key={s.id} className="flex items-center">
                <button
                  onClick={() => isDone && setStep(s.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? "bg-forest-600/20 border border-forest-600/60 text-forest-300"
                      : isDone
                      ? "text-forest-500 cursor-pointer hover:text-forest-400"
                      : "text-gray-600 cursor-not-allowed"
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                    isActive ? "bg-forest-600 text-white" : isDone ? "bg-forest-800 text-forest-400" : "bg-gray-800 text-gray-600"
                  }`}>
                    {isDone ? "✓" : s.id}
                  </span>
                  <span className="hidden sm:block">{s.title}</span>
                </button>
                {i < STEPS.length - 1 && (
                  <div className={`w-6 h-px mx-1 ${isDone ? "bg-forest-700" : "bg-gray-800"}`} />
                )}
              </div>
            );
          })}
        </div>

        {/* Form Card */}
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/70 to-[#071a0e]/70 p-6 md:p-8"
        >
          {/* Step 1: Farm */}
          {step === 1 && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <MapPin className="w-5 h-5 text-forest-400" />
                Farm Details
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Location *</label>
                  <input
                    value={form.location}
                    onChange={(e) => update("location", e.target.value)}
                    placeholder="e.g. Jaipur, Rajasthan"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Farm Size (acres) *</label>
                  <input
                    value={form.farmSize}
                    onChange={(e) => update("farmSize", e.target.value)}
                    placeholder="e.g. 2"
                    type="number"
                    min="0.1"
                    step="0.1"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Soil Type *</label>
                  <select
                    value={form.soilType}
                    onChange={(e) => update("soilType", e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white focus:outline-none focus:border-forest-600 transition-colors"
                  >
                    <option value="">Select soil type</option>
                    {SOIL_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Irrigation Type</label>
                  <select
                    value={form.irrigationType}
                    onChange={(e) => update("irrigationType", e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white focus:outline-none focus:border-forest-600 transition-colors"
                  >
                    <option value="">Select irrigation type</option>
                    {IRRIGATION_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Crop */}
          {step === 2 && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Leaf className="w-5 h-5 text-forest-400" />
                Crop Information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Crop *</label>
                  <select
                    value={form.crop}
                    onChange={(e) => update("crop", e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white focus:outline-none focus:border-forest-600 transition-colors"
                  >
                    <option value="">Select crop</option>
                    {CROP_LIST.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Crop Variety</label>
                  <input
                    value={form.cropVariety}
                    onChange={(e) => update("cropVariety", e.target.value)}
                    placeholder="e.g. Hybrid Desi"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Crop Age (days) *</label>
                  <input
                    value={form.cropAge}
                    onChange={(e) => update("cropAge", e.target.value)}
                    placeholder="e.g. 35"
                    type="number"
                    min="1"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Planting Date</label>
                  <input
                    value={form.plantingDate}
                    onChange={(e) => update("plantingDate", e.target.value)}
                    type="date"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Condition */}
          {step === 3 && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-400" />
                Current Condition
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Current Problem</label>
                  <input
                    value={form.problem}
                    onChange={(e) => update("problem", e.target.value)}
                    placeholder="e.g. Yellow leaves on lower portion"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-1.5 font-medium">Leaf Color</label>
                    <input
                      value={form.leafColor}
                      onChange={(e) => update("leafColor", e.target.value)}
                      placeholder="e.g. Yellow with green veins"
                      className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-1.5 font-medium">Recent Weather</label>
                    <input
                      value={form.recentWeather}
                      onChange={(e) => update("recentWeather", e.target.value)}
                      placeholder="e.g. Hot and dry, no rain"
                      className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Visible Symptoms</label>
                  <textarea
                    value={form.symptoms}
                    onChange={(e) => update("symptoms", e.target.value)}
                    rows={3}
                    placeholder="Describe any visible changes, patterns, or unusual signs..."
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Additional Notes</label>
                  <textarea
                    value={form.notes}
                    onChange={(e) => update("notes", e.target.value)}
                    rows={2}
                    placeholder="Any other relevant information..."
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors resize-none"
                  />
                </div>
                {/* Image upload */}
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Crop Photo (Optional)</label>
                  <div
                    onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                    onDragLeave={() => setDragOver(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setDragOver(false);
                      const file = e.dataTransfer.files[0];
                      if (file?.type.startsWith("image/")) {
                        setForm((prev) => ({ ...prev, image: file }));
                      }
                    }}
                    className={`border-2 border-dashed rounded-xl p-6 text-center transition-colors cursor-pointer ${
                      dragOver
                        ? "border-forest-500 bg-forest-500/10"
                        : form.image
                        ? "border-forest-700 bg-forest-900/20"
                        : "border-forest-900/60 hover:border-forest-800"
                    }`}
                  >
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      id="crop-image"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) setForm((prev) => ({ ...prev, image: file }));
                      }}
                    />
                    <label htmlFor="crop-image" className="cursor-pointer">
                      {form.image ? (
                        <div className="text-forest-400 text-sm font-medium">
                          ✓ {form.image.name}
                          <div className="text-xs text-gray-500 mt-1">Click to change</div>
                        </div>
                      ) : (
                        <div>
                          <Upload className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                          <div className="text-sm text-gray-500">Drag & drop or click to upload</div>
                          <div className="text-xs text-gray-600 mt-1">JPG, PNG up to 10MB</div>
                        </div>
                      )}
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Goals */}
          {step === 4 && (
            <div className="space-y-5">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-forest-400" />
                Goals & Budget
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Budget (₹)</label>
                  <input
                    value={form.budget}
                    onChange={(e) => update("budget", e.target.value)}
                    placeholder="e.g. 10000"
                    type="number"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1.5 font-medium">Expected Yield (tonnes/acre)</label>
                  <input
                    value={form.expectedYield}
                    onChange={(e) => update("expectedYield", e.target.value)}
                    placeholder="e.g. 4"
                    type="number"
                    className="w-full px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-3 font-medium">Primary Goal</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {GOALS.map((g) => (
                    <button
                      key={g}
                      onClick={() => update("primaryGoal", g)}
                      className={`px-4 py-3 rounded-xl text-sm font-medium border transition-all ${
                        form.primaryGoal === g
                          ? "bg-forest-600/20 border-forest-600/60 text-forest-300"
                          : "border-forest-900/50 text-gray-500 hover:border-forest-800 hover:text-gray-400"
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              {/* Summary preview */}
              <div className="rounded-xl border border-forest-800/40 bg-forest-900/20 p-4 text-sm text-gray-400 space-y-1.5">
                <div className="font-medium text-forest-400 mb-2">Farm Summary</div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                  <span>📍 {form.location || "—"}</span>
                  <span>📐 {form.farmSize ? `${form.farmSize} acres` : "—"}</span>
                  <span>🌱 {form.crop || "—"}</span>
                  <span>⏱ {form.cropAge ? `${form.cropAge} days` : "—"}</span>
                  <span>🪨 {form.soilType || "—"}</span>
                  <span>💧 {form.irrigationType || "—"}</span>
                </div>
              </div>
            </div>
          )}
        </motion.div>

        {/* Navigation Buttons */}
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={() => setStep((s) => Math.max(1, s - 1))}
            disabled={step === 1}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-forest-800/50 text-gray-400 hover:text-white hover:border-forest-700 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </button>

          {step < 4 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              disabled={!canProceed}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-forest-600 hover:bg-forest-500 text-white font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:-translate-y-0.5"
            >
              Continue
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleAnalyze}
              className="group flex items-center gap-3 px-7 py-3 rounded-xl bg-forest-600 hover:bg-forest-500 text-white font-bold transition-all shadow-xl shadow-forest-900/40 hover:shadow-forest-500/20 hover:-translate-y-0.5"
            >
              <Zap className="w-5 h-5 group-hover:rotate-12 transition-transform" />
              Run AI Farm Analysis
            </button>
          )}
        </div>

        {/* Disclaimer */}
        <p className="text-center text-xs text-gray-600 mt-8 max-w-md mx-auto">
          ⚠️ AgriMind AI provides decision-support recommendations and should not replace qualified agricultural professionals or local agricultural authorities.
        </p>
      </div>
    </div>
  );
}
