"use client";

import { motion } from "framer-motion";
import { ArrowDown, User, Monitor, Brain, Database, Cpu, Sprout, BarChart3 } from "lucide-react";
import { SectionTitle } from "@/components/ui/SharedComponents";

const LAYERS = [
  {
    id: "farmer",
    icon: User,
    title: "Farmer / User",
    color: "#22c55e",
    border: "border-forest-700/50",
    bg: "bg-forest-900/20",
    description: "Farmer provides farm details, crop information, current conditions, observed symptoms, and goals through the AgriMind web interface.",
    tech: ["Web Interface", "Mobile Responsive", "Next.js", "Form Input + Image Upload"],
  },
  {
    id: "frontend",
    icon: Monitor,
    title: "Frontend Application",
    color: "#38bdf8",
    border: "border-sky-700/50",
    bg: "bg-sky-900/15",
    description: "React/Next.js application providing multi-step farm analyzer, real-time analysis visualization, results dashboard, and AI advisor chat.",
    tech: ["Next.js 15", "React", "TypeScript", "Tailwind CSS", "Framer Motion", "Recharts"],
  },
  {
    id: "orchestrator",
    icon: Brain,
    title: "AI Orchestrator",
    color: "#a78bfa",
    border: "border-purple-700/50",
    bg: "bg-purple-900/15",
    description: "Central coordination layer that receives farm data, dispatches tasks to specialized agents, collects responses, and coordinates the synthesis pipeline.",
    tech: ["IBM Bob Agent", "Multi-Agent Router", "Context Manager", "Response Aggregator"],
  },
  {
    id: "agents",
    icon: Cpu,
    title: "Specialized AI Agents",
    color: "#fb923c",
    border: "border-orange-700/50",
    bg: "bg-orange-900/15",
    description: "Four domain-expert agents analyze specific dimensions: Crop Intelligence, Weather & Irrigation, Pest & Disease, and Market Intelligence.",
    tech: ["Crop Agent", "Weather Agent", "Disease Agent", "Market Agent"],
    multi: true,
  },
  {
    id: "rag",
    icon: Database,
    title: "RAG Knowledge Base",
    color: "#fbbf24",
    border: "border-yellow-700/50",
    bg: "bg-yellow-900/15",
    description: "Agricultural knowledge retrieval system. Each agent queries the knowledge base for relevant articles before generating recommendations, grounding responses in verified agricultural guidance.",
    tech: ["Semantic Search", "8+ Knowledge Articles", "Crop KB", "Disease KB", "Irrigation KB"],
  },
  {
    id: "granite",
    icon: Brain,
    title: "IBM Granite",
    color: "#60a5fa",
    border: "border-blue-700/50",
    bg: "bg-blue-900/20",
    description: "IBM's foundation model synthesizes inputs from all specialized agents and retrieved knowledge into coherent, structured farming recommendations with confidence scores.",
    tech: ["IBM Granite Foundation Model", "Multi-context reasoning", "Structured output", "Safety guidelines"],
  },
  {
    id: "recommendation",
    icon: Sprout,
    title: "Recommendation Engine",
    color: "#34d399",
    border: "border-emerald-700/50",
    bg: "bg-emerald-900/15",
    description: "Post-processing layer that structures IBM Granite's output into actionable format: executive summary, 7-day action plan, confidence scores, and evidence sources.",
    tech: ["Response Structuring", "Action Plan Generation", "Confidence Scoring", "Evidence Linking"],
  },
  {
    id: "output",
    icon: BarChart3,
    title: "Farmer Action Plan",
    color: "#22c55e",
    border: "border-forest-700/50",
    bg: "bg-forest-900/20",
    description: "Final output delivered to farmer: personalized farm intelligence report with crop health assessment, disease risk, irrigation guidance, market insights, and 7-day action plan.",
    tech: ["Farm Report", "7-Day Plan", "Agent Evidence", "Risk Assessment", "Market Insights"],
  },
];

export default function ArchitecturePage() {
  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-3xl mx-auto">
        <SectionTitle
          badge="System Architecture"
          title="How AgriMind Works"
          subtitle="A multi-layered AI architecture combining IBM Granite, specialized agents, and RAG to transform farm data into actionable intelligence."
        />

        {/* Architecture diagram */}
        <div className="space-y-2">
          {LAYERS.map((layer, i) => {
            const Icon = layer.icon;
            return (
              <motion.div
                key={layer.id}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <div
                  className={`rounded-2xl border ${layer.border} ${layer.bg} p-5`}
                >
                  <div className="flex items-start gap-4">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${layer.color}20` }}
                    >
                      <Icon className="w-5 h-5" style={{ color: layer.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-white text-sm">{layer.title}</h3>
                        <span className="text-xs px-1.5 py-0.5 rounded font-mono" style={{ backgroundColor: `${layer.color}15`, color: layer.color }}>
                          Layer {i + 1}
                        </span>
                      </div>
                      <p className="text-gray-400 text-xs leading-relaxed mb-2">{layer.description}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {layer.tech.map((t) => (
                          <span key={t} className="text-xs px-2 py-0.5 rounded bg-white/5 border border-white/5 text-gray-500">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {i < LAYERS.length - 1 && (
                  <div className="flex justify-center my-1">
                    <ArrowDown className="w-4 h-4 text-gray-700" />
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* IBM summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-10 p-6 rounded-2xl border border-blue-800/30 bg-blue-900/10 text-center"
        >
          <h3 className="font-bold text-blue-300 mb-2">IBM Technology Integration</h3>
          <p className="text-gray-400 text-sm mb-4">
            AgriMind AI is built on IBM&#39;s enterprise AI stack, combining IBM Granite&#39;s language understanding
            with IBM Bob Agent&#39;s orchestration capabilities to deliver production-ready agricultural intelligence.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {[
              { name: "IBM Granite", desc: "Foundation model for reasoning & generation" },
              { name: "IBM Bob Agent", desc: "Agent orchestration & workflow management" },
              { name: "RAG", desc: "Knowledge grounding for reliable recommendations" },
            ].map((tech) => (
              <div key={tech.name} className="px-4 py-2 rounded-xl border border-blue-700/30 bg-blue-800/10 text-left">
                <div className="text-blue-300 text-sm font-semibold">{tech.name}</div>
                <div className="text-gray-500 text-xs">{tech.desc}</div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* What&#39;s real vs simulated */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-6 p-5 rounded-2xl border border-amber-800/30 bg-amber-900/10"
        >
          <h3 className="font-semibold text-amber-400 mb-3 text-sm">Real vs. Demo in This Prototype</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <div className="text-green-400 font-semibold mb-1.5">✓ Real / Implemented</div>
              <ul className="space-y-1 text-gray-400">
                <li>• Multi-step farm data collection</li>
                <li>• Multi-agent architecture & visualization</li>
                <li>• Animated agent analysis sequence</li>
                <li>• RAG knowledge base (8 articles)</li>
                <li>• Structured AI response format</li>
                <li>• Weather, disease, market UI</li>
                <li>• AI chat advisor with rule-based responses</li>
              </ul>
            </div>
            <div>
              <div className="text-amber-400 font-semibold mb-1.5">⚠️ Simulated / Demo</div>
              <ul className="space-y-1 text-gray-400">
                <li>• IBM Granite API calls (simulated)</li>
                <li>• Live weather data (demo values)</li>
                <li>• Real market prices (demo data)</li>
                <li>• Computer vision disease detection</li>
                <li>• Real-time agent communication</li>
                <li>• Database persistence</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
