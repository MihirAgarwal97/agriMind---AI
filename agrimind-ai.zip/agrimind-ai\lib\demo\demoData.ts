// Demo farm data for hackathon demonstrations
export const DEMO_FARM = {
  // Farm info
  location: "Jaipur, Rajasthan",
  farmSize: "2",
  soilType: "Loamy",
  irrigationType: "Drip Irrigation",
  // Crop info
  crop: "Tomato",
  cropVariety: "Hybrid Desi",
  cropAge: "35",
  plantingDate: "2024-03-15",
  // Conditions
  problem: "Yellow leaves on lower portion of plant",
  leafColor: "Yellow with green veins",
  symptoms: "Lower leaves yellowing, some wilting in afternoon",
  recentWeather: "Hot and dry, no rain in 10 days",
  notes: "First time growing tomatoes, small family farm",
  // Goals
  budget: "10000",
  expectedYield: "4",
  primaryGoal: "Prevent Disease",
};

export const DEMO_ANALYSIS_RESULT = {
  farmId: "DEMO-001",
  timestamp: new Date().toISOString(),
  location: "Jaipur, Rajasthan",
  crop: "Tomato",
  farmSize: "2 acres",
  cropAge: "35 days",

  scores: {
    cropHealth: 74,
    waterStatus: "Moderate Stress",
    diseaseRisk: "Medium",
    weatherRisk: "Low-Medium",
    marketOpportunity: "Good",
  },

  agentResponses: {
    crop: {
      agent: "Crop Intelligence Agent",
      status: "complete",
      confidence: 82,
      analysis:
        "Tomato crop is approximately 35 days old and appears to be in an active vegetative to early flowering transition stage. This is a critical growth period requiring balanced nutrition and consistent moisture. The yellowing of lower leaves is consistent with nitrogen deficiency, magnesium deficiency, or early-stage fungal stress. Focus on balanced NPK nutrition, consistent irrigation without waterlogging, and monitoring for stress patterns.",
      recommendations: [
        "Check nitrogen availability in soil — lower leaf yellowing is a classic N-deficiency signal",
        "Ensure magnesium levels are adequate, especially in loamy soil with high drainage",
        "Monitor flowering development — stress at this stage can reduce fruit set",
        "Consider foliar micronutrient spray if soil amendment takes too long",
      ],
      keyFindings: ["35-day vegetative/flowering stage", "N or Mg deficiency likely", "Critical monitoring window"],
    },
    weather: {
      agent: "Weather & Irrigation Agent",
      status: "complete",
      confidence: 88,
      analysis:
        "Current demo weather conditions for Jaipur suggest high temperatures (38-42°C) and low humidity. With no rainfall in 10 days, soil moisture is likely below optimal for tomato at this stage. Drip irrigation is a good choice — ensure it runs for adequate duration. Avoid overhead irrigation which increases fungal risk. Morning irrigation (6-8 AM) is preferred to reduce evaporation and leaf wetness.",
      recommendations: [
        "Irrigate for 45-60 minutes per day with drip at this crop age",
        "Irrigate early morning to minimize evaporation",
        "Check soil moisture at 6-inch depth — should be moist but not waterlogged",
        "Watch for upcoming heat wave probability — shade net may be beneficial",
      ],
      weatherData: {
        temp: 40,
        humidity: 28,
        rainProb: 15,
        windSpeed: 12,
        soilMoisture: 34,
      },
    },
    disease: {
      agent: "Pest & Disease Agent",
      status: "complete",
      confidence: 71,
      analysis:
        "Yellowing leaves in tomato at 35 days can have multiple causes. In the absence of image-based analysis, the most probable causes based on described symptoms (lower leaf yellowing, green veins, afternoon wilting) include: (1) Magnesium or nitrogen deficiency, (2) Fusarium or Verticillium wilt early stage, (3) Spider mite activity causing chlorosis. Inspect lower leaf undersides for mite webbing, check stem base for brown discoloration, and examine soil drainage before selecting treatment.",
      possibleIssues: [
        { name: "Nitrogen Deficiency", probability: 45, severity: "Moderate" },
        { name: "Magnesium Deficiency", probability: 30, severity: "Low-Moderate" },
        { name: "Early Fusarium Wilt", probability: 15, severity: "High if confirmed" },
        { name: "Spider Mite Damage", probability: 10, severity: "Moderate" },
      ],
      recommendations: [
        "Inspect lower leaf undersides for spider mite webbing",
        "Check stem base cross-section for brown vascular discoloration",
        "Test soil pH — magnesium availability is pH sensitive",
        "Do NOT apply fungicide without confirming fungal presence",
        "Consult local agricultural extension officer if symptoms spread rapidly",
      ],
    },
    market: {
      agent: "Market Intelligence Agent",
      status: "complete",
      confidence: 65,
      analysis:
        "Demo market data suggests tomato prices in Rajasthan typically peak in May-June before monsoon. At 35 days, your crop is approximately 45-60 days from harvest. Monitor local Jaipur mandi prices weekly. Consider storage or staggered harvesting strategy to avoid market flooding. Input costs should be controlled — budget ₹10,000 suggests moderate operations; prioritize high-ROI interventions.",
      marketData: {
        currentPrice: 18,
        trend: "Rising",
        harvestWindow: "May-June",
        expectedRevenue: "₹28,000 - ₹40,000",
        inputCostRemaining: "₹4,000 - ₹6,000",
      },
      recommendations: [
        "Monitor Jaipur mandi prices weekly on Agmarknet",
        "Consider selling in batches to avoid single-day price risk",
        "Budget allows for one foliar spray + one soil amendment",
        "Target early June harvest if crop health improves",
      ],
    },
  },

  graniteSynthesis: {
    summary:
      "Based on combined multi-agent analysis, your tomato crop is experiencing moderate stress likely caused by nutrient insufficiency (nitrogen or magnesium) combined with heat and irrigation stress. The symptoms do not currently indicate a serious disease outbreak. Priority actions are: verify irrigation adequacy, conduct a visual inspection for nutrient deficiency patterns, and consider a mild foliar spray. Avoid applying pesticides or fungicides without confirmed diagnosis as this increases cost and may harm beneficial insects.",
    confidence: 79,
    evidenceSources: [
      "Agricultural Knowledge Base: Tomato Nutrition Guide",
      "Agricultural Knowledge Base: Rajasthan Kharif/Rabi Climate Patterns",
      "Agricultural Knowledge Base: Integrated Pest Management — Tomato",
      "Agricultural Knowledge Base: Drip Irrigation Best Practices",
    ],
    riskLevel: "Medium",
    urgency: "Monitor — Act within 3-5 days",
  },

  actionPlan: [
    {
      day: 1,
      title: "Visual Inspection",
      description: "Inspect lower leaves closely. Check undersides for mites, look for patterns of yellowing (tip vs. uniform). Photograph affected leaves for record.",
      priority: "High",
      category: "diagnosis",
      details: "Start at 6 AM before heat of day. Check 10-15 plants across the field. Note which rows are most affected.",
    },
    {
      day: 2,
      title: "Soil Moisture Check",
      description: "Measure soil moisture at 6-inch depth in multiple field zones. Ensure drip irrigation system is functioning correctly.",
      priority: "High",
      category: "irrigation",
      details: "Use a soil moisture meter or manual finger test. Check drip emitters for blockage. Document moisture variation across field.",
    },
    {
      day: 3,
      title: "Irrigation Adjustment",
      description: "Based on Day 2 findings, adjust irrigation duration. Consider adding 15 minutes to daily cycle if soil is dry.",
      priority: "Medium",
      category: "irrigation",
      details: "Run irrigation between 6-8 AM. Avoid evening irrigation to reduce fungal risk in humid night conditions.",
    },
    {
      day: 4,
      title: "Nutrient Assessment",
      description: "Purchase soil test kit or consult local agricultural extension for soil NPK status. Plan foliar micronutrient spray if deficiency is confirmed.",
      priority: "Medium",
      category: "nutrition",
      details: "Focus on nitrogen and magnesium levels. Local Krishi Vigyan Kendra can assist with soil testing in Rajasthan.",
    },
    {
      day: 5,
      title: "Preventive Action",
      description: "If nutrient deficiency is confirmed, apply approved foliar spray per product label guidance. If pest or disease is found, consult agricultural expert before treatment.",
      priority: "Medium",
      category: "treatment",
      details: "Follow product label dosage. Avoid applying during peak heat (10 AM - 4 PM). Spray in the evening.",
    },
    {
      day: 6,
      title: "Re-Inspection",
      description: "Check if symptoms have stabilized or worsened. Compare with Day 1 photographs. Monitor new growth for healthy leaf color.",
      priority: "Medium",
      category: "monitoring",
      details: "New leaves should show improvement within 4-5 days of nutrient correction. If worsening, escalate to agricultural expert.",
    },
    {
      day: 7,
      title: "AI Health Review",
      description: "Run another AgriMind analysis with updated observations. Adjust treatment plan based on progress. Document outcomes.",
      priority: "Low",
      category: "review",
      details: "Update your farm record with observations. Share photos with AgriMind Disease Detection for improved assessment.",
    },
  ],

  weatherForecast: [
    { day: "Mon", temp: 40, rain: 5, humidity: 28, icon: "sunny" },
    { day: "Tue", temp: 41, rain: 3, humidity: 26, icon: "sunny" },
    { day: "Wed", temp: 38, rain: 20, humidity: 35, icon: "partly_cloudy" },
    { day: "Thu", temp: 36, rain: 40, humidity: 45, icon: "cloudy" },
    { day: "Fri", temp: 34, rain: 60, humidity: 55, icon: "rain" },
    { day: "Sat", temp: 33, rain: 35, humidity: 50, icon: "partly_cloudy" },
    { day: "Sun", temp: 37, rain: 10, humidity: 38, icon: "sunny" },
  ],
};

export const DEMO_WEATHER = {
  current: {
    temp: 40,
    feelsLike: 44,
    humidity: 28,
    windSpeed: 12,
    windDirection: "NW",
    visibility: 8,
    uvIndex: 9,
    pressure: 1005,
    soilMoisture: 34,
    rainProb: 15,
    description: "Hot and dry",
  },
  hourly: [
    { hour: "06:00", temp: 32, rain: 5 },
    { hour: "08:00", temp: 35, rain: 3 },
    { hour: "10:00", temp: 38, rain: 2 },
    { hour: "12:00", temp: 41, rain: 1 },
    { hour: "14:00", temp: 43, rain: 0 },
    { hour: "16:00", temp: 42, rain: 2 },
    { hour: "18:00", temp: 39, rain: 8 },
    { hour: "20:00", temp: 35, rain: 10 },
    { hour: "22:00", temp: 33, rain: 12 },
  ],
  irrigation: {
    recommendation: "Irrigation recommended today — soil moisture is below optimal for tomato at 35 days.",
    window: "6:00 AM – 8:00 AM",
    duration: "55 minutes",
    waterSavingScore: 78,
    efficiency: 85,
    nextRainIn: "3 days",
  },
};

export const DEMO_MARKET = {
  crop: "Tomato",
  location: "Jaipur, Rajasthan",
  currentPrice: 18,
  weeklyChange: +2.5,
  trend: "Rising",
  lastUpdated: "Demo Data",
  priceHistory: [
    { date: "Mar 1", price: 12 },
    { date: "Mar 8", price: 14 },
    { date: "Mar 15", price: 13 },
    { date: "Mar 22", price: 16 },
    { date: "Mar 29", price: 15 },
    { date: "Apr 5", price: 17 },
    { date: "Apr 12", price: 18 },
  ],
  insight:
    "Based on demo market data, tomato prices in Rajasthan typically rise from April through June. Monitor local Jaipur mandi prices weekly. Consider planning harvest for early June for potentially better prices.",
  costAnalysis: {
    inputCost: 4500,
    expectedRevenue: 34000,
    projectedProfit: 29500,
    roi: "555%",
  },
};

export const KNOWLEDGE_BASE = [
  {
    id: "kb-001",
    category: "Crop Management",
    title: "Tomato Crop Stages and Nutrition Guide",
    summary:
      "Tomatoes require different nutrients at different growth stages. Nitrogen is critical during vegetative stage (0-35 days), phosphorus during root development and flowering, and potassium during fruit development.",
    content:
      "Tomato crop management requires careful attention to growth stage nutrition. During vegetative stage (0-35 days), focus on nitrogen for leaf and stem growth. Calcium and boron are essential to prevent blossom end rot. Magnesium deficiency shows as interveinal chlorosis (yellowing between green veins) on lower leaves. Regular soil testing and foliar monitoring are recommended.",
    tags: ["tomato", "nutrition", "NPK", "nitrogen", "magnesium"],
    relevanceScore: 95,
  },
  {
    id: "kb-002",
    category: "Disease Management",
    title: "Tomato Leaf Yellowing: Diagnosis Guide",
    summary:
      "Yellowing tomato leaves can indicate nutrient deficiency, water stress, fungal disease, or pest damage. Diagnosis requires systematic inspection.",
    content:
      "Yellow leaves on tomato plants require systematic diagnosis. Lower leaf yellowing starting from tips indicates nitrogen deficiency. Interveinal yellowing (green veins, yellow between) suggests magnesium deficiency. Yellowing with wilting may indicate Fusarium or Verticillium wilt — check stem cross-section for brown vascular tissue. Mottled yellowing with webbing on undersides indicates spider mites. Never apply treatment without confirmed diagnosis.",
    tags: ["tomato", "yellowing", "disease", "diagnosis", "deficiency"],
    relevanceScore: 98,
  },
  {
    id: "kb-003",
    category: "Irrigation",
    title: "Drip Irrigation for Tomato in Semi-Arid Climate",
    summary:
      "Drip irrigation is highly efficient for tomato cultivation in semi-arid regions like Rajasthan. Proper scheduling saves 40-60% water compared to flood irrigation.",
    content:
      "For tomato cultivation in Rajasthan using drip irrigation: water requirement is approximately 400-600mm per season. During vegetative stage, irrigate for 45-60 minutes daily with drip. During flowering and fruiting, increase to 60-90 minutes. Schedule irrigation between 6-8 AM to minimize evaporation. Soil moisture should be maintained at 60-80% field capacity. Install soil moisture sensors for precision irrigation.",
    tags: ["drip irrigation", "water", "Rajasthan", "semi-arid", "tomato"],
    relevanceScore: 90,
  },
  {
    id: "kb-004",
    category: "Pest Management",
    title: "Integrated Pest Management for Tomato",
    summary:
      "IPM combines biological, cultural, and chemical controls to manage pests effectively while minimizing environmental impact and cost.",
    content:
      "Tomato pest management should follow IPM principles. Common pests include aphids, whitefly, fruit borer, and spider mites. For spider mites (indicated by fine webbing, yellowing, stippled leaves): increase humidity, introduce predatory mites, or use neem oil spray as organic option. For aphids: check for natural predators (ladybugs) before applying insecticide. Chemical control should be the last resort and must follow product labels and local agricultural authority guidance.",
    tags: ["IPM", "pests", "spider mites", "aphids", "tomato", "organic"],
    relevanceScore: 85,
  },
  {
    id: "kb-005",
    category: "Soil",
    title: "Loamy Soil Management for Vegetable Crops",
    summary:
      "Loamy soil is ideal for vegetable cultivation. It provides good drainage while retaining adequate moisture. Regular organic matter addition maintains soil health.",
    content:
      "Loamy soil in Rajasthan typically has good drainage but may need organic matter supplementation. For tomato: optimal pH is 6.0-6.8. Check pH annually — low pH reduces magnesium and calcium availability. Add well-composted farmyard manure (FYM) at 10-15 tonnes/hectare before planting. Mulching with dried crop residue reduces moisture loss and maintains soil temperature. Avoid over-tilling to preserve soil structure.",
    tags: ["loamy soil", "pH", "organic matter", "Rajasthan", "vegetable"],
    relevanceScore: 88,
  },
  {
    id: "kb-006",
    category: "Weather",
    title: "Heat Stress Management in Tomato",
    summary:
      "Tomato faces heat stress above 35°C, causing flower drop, poor fruit set, and physiological disorders. Shade netting and timely irrigation can reduce impact.",
    content:
      "In Jaipur, April-June temperatures frequently exceed 40°C. Tomato flowers abort above 35°C and pollen viability reduces. Management strategies: install 30-40% shade net over crop, irrigate early morning, avoid nitrogen deficiency which worsens heat stress, apply potassium spray to improve heat tolerance, schedule critical operations (spraying, harvesting) before 9 AM or after 5 PM.",
    tags: ["heat stress", "Jaipur", "Rajasthan", "shade net", "temperature"],
    relevanceScore: 92,
  },
  {
    id: "kb-007",
    category: "Fertilization",
    title: "Foliar Nutrition Spray Guide for Tomato",
    summary:
      "Foliar sprays provide rapid correction of nutrient deficiencies. Use only confirmed deficiencies and follow label guidelines.",
    content:
      "Foliar nutrition is a rapid intervention for nutrient deficiency in tomato. For nitrogen deficiency: 1% urea solution spray (10g/L water) is commonly used — apply early morning, avoid peak heat. For magnesium deficiency: 0.5% magnesium sulfate solution (5g/L water). Always conduct a patch test on a few leaves before full-field application. Follow local agricultural authority dosage guidance. Keep records of all foliar applications. Avoid spraying before expected rainfall.",
    tags: ["foliar spray", "nutrition", "urea", "magnesium sulfate", "tomato"],
    relevanceScore: 87,
  },
  {
    id: "kb-008",
    category: "Harvesting",
    title: "Tomato Harvest Timing and Post-Harvest Management",
    summary:
      "Optimal harvest timing balances crop maturity, market prices, and storage considerations. Post-harvest handling significantly affects market value.",
    content:
      "Tomato for fresh market should be harvested at breaker to turning stage (color change from green to pink-red). In Rajasthan, tomatoes planted in March are typically ready for harvest in late May to June. Harvesting early morning reduces field heat and extends shelf life. Sort by size and color for premium market. Minimize handling damage. For distant markets, harvest at breaker stage. For local markets, allow to ripen to turning stage for better price.",
    tags: ["harvest", "post-harvest", "market", "storage", "tomato"],
    relevanceScore: 80,
  },
];
