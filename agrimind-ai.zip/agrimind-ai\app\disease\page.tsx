"use client";

import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, Scan, AlertTriangle, CheckCircle2, Brain, X, Image as ImageIcon } from "lucide-react";
import { DemoBadge } from "@/components/ui/SharedComponents";

const DEMO_DISEASES = [
  {
    name: "Possible Nitrogen Deficiency",
    confidence: 68,
    severity: "Moderate",
    symptoms: ["Lower leaf yellowing", "Green veins visible", "Older leaves affected first"],
    action: "Inspect pattern carefully. Consider soil test. If confirmed, consult agronomist for appropriate nitrogen amendment.",
    color: "text-yellow-400",
    border: "border-yellow-700/40",
  },
  {
    name: "Possible Magnesium Deficiency",
    confidence: 45,
    severity: "Low-Moderate",
    symptoms: ["Interveinal chlorosis", "Younger leaves unaffected", "Loamy soil with high drainage"],
    action: "Test soil pH and magnesium levels. Consult agricultural extension for appropriate foliar treatment if confirmed.",
    color: "text-orange-400",
    border: "border-orange-700/40",
  },
  {
    name: "Possible Early Fungal Stress",
    confidence: 22,
    severity: "Needs Monitoring",
    symptoms: ["Cannot confirm without image analysis", "Physical inspection recommended"],
    action: "Check stem base for brown vascular discoloration. Do not apply fungicide without confirmation.",
    color: "text-red-400",
    border: "border-red-700/40",
  },
];

export default function DiseasePage() {
  const [image, setImage] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>("");
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed, setAnalyzed] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (!file.type.startsWith("image/")) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      setImage(e.target?.result as string);
      setAnalyzed(false);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    setAnalyzing(true);
    await new Promise((r) => setTimeout(r, 2800));
    setAnalyzing(false);
    setAnalyzed(true);
  };

  const reset = () => {
    setImage(null);
    setFileName("");
    setAnalyzed(false);
    setAnalyzing(false);
  };

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-4xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Crop Disease Detection</h1>
          <p className="text-gray-400">Upload a photo of your crop for AI-assisted assessment</p>
          <div className="flex items-center justify-center gap-2 mt-3">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <p className="text-amber-400 text-xs">
              AI-assisted assessment only. Always consult a qualified agricultural expert for confirmation.
            </p>
          </div>
        </motion.div>

        {/* Upload area */}
        {!image ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-8"
          >
            <input
              ref={inputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFile(file);
              }}
            />
            <div
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                const file = e.dataTransfer.files[0];
                if (file) handleFile(file);
              }}
              onClick={() => inputRef.current?.click()}
              className={`cursor-pointer rounded-2xl border-2 border-dashed p-16 text-center transition-all ${
                dragOver
                  ? "border-forest-500 bg-forest-500/10"
                  : "border-forest-900/60 hover:border-forest-700/60 hover:bg-forest-900/10"
              }`}
            >
              <ImageIcon className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-lg font-semibold text-white mb-2">Upload Crop Photo</p>
              <p className="text-gray-500 text-sm mb-4">Drag & drop or click to upload</p>
              <p className="text-gray-600 text-xs">JPG, PNG, WebP up to 20MB</p>
              <div className="mt-6">
                <button className="px-6 py-2.5 rounded-xl bg-forest-700 hover:bg-forest-600 text-white text-sm font-medium transition-colors">
                  Choose Image
                </button>
              </div>
            </div>

            {/* Demo notice */}
            <div className="mt-4 p-4 rounded-xl border border-amber-800/30 bg-amber-900/10 text-center">
              <p className="text-amber-400 text-sm font-medium mb-1">Demo Mode Available</p>
              <p className="text-gray-500 text-xs">You can upload any plant image. The system will run a simulated AI-assisted assessment based on the demo farm data.</p>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mb-8"
          >
            <div className="rounded-2xl border border-forest-900/60 overflow-hidden bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70">
              <div className="flex items-center justify-between p-4 border-b border-forest-900/40">
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-forest-400" />
                  <span className="text-sm text-gray-300">{fileName}</span>
                </div>
                <button onClick={reset} className="p-1.5 rounded-lg hover:bg-gray-800 text-gray-500 hover:text-gray-300 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="relative">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={image}
                  alt="Uploaded crop"
                  className="w-full max-h-64 object-cover"
                />
                {analyzing && (
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-3">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      <Scan className="w-10 h-10 text-forest-400" />
                    </motion.div>
                    <p className="text-white font-medium">AI analyzing crop image...</p>
                    <div className="flex gap-1.5">
                      {[0, 1, 2, 3].map((i) => (
                        <motion.div
                          key={i}
                          className="w-2 h-2 rounded-full bg-forest-400"
                          animate={{ opacity: [0.3, 1, 0.3] }}
                          transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
              {!analyzed && !analyzing && (
                <div className="p-4 flex justify-center">
                  <button
                    onClick={handleAnalyze}
                    className="flex items-center gap-2 px-6 py-3 rounded-xl bg-forest-600 hover:bg-forest-500 text-white font-semibold transition-all"
                  >
                    <Scan className="w-5 h-5" />
                    Analyze for Disease & Issues
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* Results */}
        <AnimatePresence>
          {analyzed && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-3 mb-4">
                <Brain className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold text-white">AI-Assisted Assessment</h3>
                <DemoBadge />
                <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/20">IBM Granite</span>
              </div>

              <div className="p-4 rounded-xl border border-amber-700/30 bg-amber-900/10 mb-4">
                <p className="text-amber-400 text-sm">
                  <strong>Important:</strong> These are AI-assisted possibilities based on visual and contextual analysis.
                  This is NOT a definitive diagnosis. Consult a qualified agricultural expert for confirmation before taking any treatment action.
                </p>
              </div>

              {DEMO_DISEASES.map((disease, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.15 }}
                  className={`rounded-2xl border ${disease.border} bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-5`}
                >
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <h4 className={`font-semibold ${disease.color} mb-0.5`}>{disease.name}</h4>
                      <span className="text-xs text-gray-500">Severity: {disease.severity}</span>
                    </div>
                    <div className="flex-shrink-0 text-right">
                      <div className={`text-lg font-bold ${disease.color}`}>{disease.confidence}%</div>
                      <div className="text-xs text-gray-500">confidence</div>
                    </div>
                  </div>

                  {/* Confidence bar */}
                  <div className="h-1.5 rounded-full bg-gray-800 mb-4 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${disease.confidence}%` }}
                      transition={{ duration: 0.8, delay: i * 0.1 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: disease.confidence > 60 ? "#eab308" : disease.confidence > 40 ? "#f97316" : "#6b7280" }}
                    />
                  </div>

                  <div className="mb-3">
                    <p className="text-xs text-gray-500 mb-1.5 font-medium">Observed Symptoms:</p>
                    <ul className="space-y-1">
                      {disease.symptoms.map((s, j) => (
                        <li key={j} className="text-xs text-gray-400 flex items-center gap-1.5">
                          <span className="w-1 h-1 rounded-full bg-gray-600" />
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-3 rounded-lg bg-forest-900/30 border border-forest-800/30">
                    <p className="text-xs text-gray-400">
                      <strong className="text-forest-400">Recommended Next Step: </strong>
                      {disease.action}
                    </p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
