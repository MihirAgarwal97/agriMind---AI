"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface ScoreGaugeProps {
  score: number;
  label: string;
  size?: number;
  showNumber?: boolean;
}

export function ScoreGauge({ score, label, size = 80, showNumber = true }: ScoreGaugeProps) {
  const radius = (size - 12) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const color =
    score >= 80 ? "#22c55e" : score >= 60 ? "#eab308" : score >= 40 ? "#f97316" : "#ef4444";

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.06)"
            strokeWidth={6}
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={6}
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.5, ease: "easeOut" }}
          />
        </svg>
        {showNumber && (
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.span
              className="text-lg font-bold"
              style={{ color }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              {score}
            </motion.span>
          </div>
        )}
      </div>
      <span className="text-xs text-gray-400 text-center font-medium">{label}</span>
    </div>
  );
}

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const s = status.toLowerCase();
  const config = s.includes("low")
    ? { bg: "bg-green-500/15", text: "text-green-400", dot: "bg-green-400" }
    : s.includes("good") || s.includes("optimal") || s.includes("complete")
    ? { bg: "bg-green-500/15", text: "text-green-400", dot: "bg-green-400" }
    : s.includes("medium") || s.includes("moderate") || s.includes("analyzing")
    ? { bg: "bg-yellow-500/15", text: "text-yellow-400", dot: "bg-yellow-400" }
    : s.includes("high") || s.includes("error")
    ? { bg: "bg-red-500/15", text: "text-red-400", dot: "bg-red-400" }
    : { bg: "bg-gray-500/15", text: "text-gray-400", dot: "bg-gray-400" };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium",
        config.bg,
        config.text,
        className
      )}
    >
      <span className={cn("w-1.5 h-1.5 rounded-full", config.dot)} />
      {status}
    </span>
  );
}

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
}

export function Card({ children, className, hover = false, glow = false }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/80 to-[#071a0e]/80",
        hover && "card-hover cursor-pointer",
        glow && "glow-green",
        className
      )}
    >
      {children}
    </div>
  );
}

interface SectionTitleProps {
  badge?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
}

export function SectionTitle({ badge, title, subtitle, center = true }: SectionTitleProps) {
  return (
    <div className={cn("mb-12", center && "text-center")}>
      {badge && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-forest-700/50 bg-forest-900/30 text-forest-400 text-xs font-medium mb-4"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-forest-400 animate-pulse" />
          {badge}
        </motion.div>
      )}
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="text-3xl md:text-4xl font-bold text-white"
      >
        {title}
      </motion.h2>
      {subtitle && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-3 text-gray-400 text-lg max-w-2xl mx-auto"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}

export function DemoBadge() {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-amber-500/15 text-amber-400 border border-amber-500/20">
      <span className="w-1 h-1 rounded-full bg-amber-400" />
      Demo Data
    </span>
  );
}

export function IBMBadge() {
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-blue-500/30 bg-blue-500/10">
      <span className="text-blue-400 text-xs font-bold tracking-wider">IBM</span>
      <span className="text-gray-400 text-xs">Granite + Bob Agent</span>
    </div>
  );
}
