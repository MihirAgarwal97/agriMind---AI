"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Send, User, Sprout, Loader2, ChevronDown } from "lucide-react";
import { getAgriAdvice } from "@/lib/ai/agriMind";
import type { ChatMessage } from "@/lib/types";

const EXAMPLE_QUESTIONS = [
  "What should I do if my tomato leaves are turning yellow?",
  "When should I irrigate my wheat crop?",
  "How can I reduce water usage on my farm?",
  "What should I check before applying fertilizer?",
  "How can I improve my tomato crop yield?",
];

const INITIAL_MESSAGE: ChatMessage = {
  id: "init",
  role: "assistant",
  content: "Hello! I'm AgriMind, your AI farming advisor. Ask me anything about crop health, irrigation, disease management, or market considerations. I'll provide structured guidance based on agricultural best practices.",
  timestamp: new Date(),
};

export default function AdvisorPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([INITIAL_MESSAGE]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (text?: string) => {
    const q = (text || input).trim();
    if (!q || loading) return;
    setInput("");

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: q,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const response = await getAgriAdvice(q);
      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.answer,
        timestamp: new Date(),
        structured: response,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      setMessages((prev) => [...prev, {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "I'm unable to process that request right now. Please try again or use the Farm Analyzer for a complete analysis.",
        timestamp: new Date(),
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-20 flex flex-col" style={{ maxHeight: "100vh" }}>
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative flex-1 flex flex-col max-w-3xl mx-auto w-full px-4 pb-4">
        {/* Header */}
        <div className="py-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Brain className="w-6 h-6 text-forest-400" />
            <h1 className="text-2xl font-bold text-white">Ask AgriMind</h1>
          </div>
          <p className="text-gray-500 text-sm">AI farming advisor powered by IBM Granite</p>
        </div>

        {/* Chat container */}
        <div className="flex-1 overflow-y-auto space-y-4 pb-4" style={{ minHeight: 0, maxHeight: "calc(100vh - 260px)" }}>
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {msg.role === "assistant" && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-forest-700 to-forest-900 flex items-center justify-center flex-shrink-0 mt-1">
                    <Sprout className="w-4 h-4 text-forest-300" />
                  </div>
                )}

                <div className={`max-w-[85%] ${msg.role === "user" ? "ml-auto" : ""}`}>
                  <div className={`rounded-2xl px-4 py-3 ${
                    msg.role === "user"
                      ? "bg-forest-700/30 border border-forest-700/40 text-white rounded-tr-sm"
                      : "bg-gradient-to-br from-[#0d2918]/80 to-[#071a0e]/80 border border-forest-900/50 text-gray-300 rounded-tl-sm"
                  }`}>
                    <p className="text-sm leading-relaxed">{msg.content}</p>
                  </div>

                  {/* Structured response */}
                  {msg.structured && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="mt-2"
                    >
                      <button
                        onClick={() => setExpandedId(expandedId === msg.id ? null : msg.id)}
                        className="text-xs text-forest-500 hover:text-forest-400 flex items-center gap-1 mb-2"
                      >
                        See structured guidance
                        <ChevronDown className={`w-3 h-3 transition-transform ${expandedId === msg.id ? "rotate-180" : ""}`} />
                      </button>

                      <AnimatePresence>
                        {expandedId === msg.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            className="space-y-2 overflow-hidden"
                          >
                            {[
                              { label: "Recommended Action", value: msg.structured.action, color: "border-forest-700/40 bg-forest-900/20", textColor: "text-forest-400" },
                              { label: "Why", value: msg.structured.why, color: "border-blue-700/40 bg-blue-900/15", textColor: "text-blue-400" },
                              { label: "Risk", value: msg.structured.risk, color: "border-orange-700/40 bg-orange-900/15", textColor: "text-orange-400" },
                              { label: "Next Step", value: msg.structured.nextStep, color: "border-purple-700/40 bg-purple-900/15", textColor: "text-purple-400" },
                            ].map((item) => (
                              <div key={item.label} className={`rounded-xl border p-3 ${item.color}`}>
                                <div className={`text-xs font-bold mb-1 ${item.textColor}`}>{item.label}</div>
                                <p className="text-xs text-gray-400 leading-relaxed">{item.value}</p>
                              </div>
                            ))}
                            {msg.structured.sources && msg.structured.sources.length > 0 && (
                              <div className="text-xs text-gray-600 p-2">
                                <strong>Knowledge sources:</strong>{" "}
                                {msg.structured.sources.join(", ")}
                              </div>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  )}

                  <div className="text-xs text-gray-700 mt-1 px-1">
                    {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>

                {msg.role === "user" && (
                  <div className="w-8 h-8 rounded-xl bg-gray-800 flex items-center justify-center flex-shrink-0 mt-1">
                    <User className="w-4 h-4 text-gray-400" />
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>

          {loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-forest-700 to-forest-900 flex items-center justify-center flex-shrink-0">
                <Sprout className="w-4 h-4 text-forest-300" />
              </div>
              <div className="rounded-2xl rounded-tl-sm border border-forest-900/50 bg-gradient-to-br from-[#0d2918]/80 to-[#071a0e]/80 px-4 py-3 flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-forest-400 animate-spin" />
                <span className="text-sm text-gray-500">AgriMind is thinking...</span>
              </div>
            </motion.div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Example questions */}
        {messages.length <= 1 && (
          <div className="mb-4">
            <p className="text-xs text-gray-600 mb-2">Example questions:</p>
            <div className="flex flex-wrap gap-2">
              {EXAMPLE_QUESTIONS.map((q) => (
                <button
                  key={q}
                  onClick={() => sendMessage(q)}
                  className="text-xs px-3 py-1.5 rounded-lg border border-forest-900/50 text-gray-500 hover:text-forest-300 hover:border-forest-700/50 transition-colors text-left"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="flex gap-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
            placeholder="Ask about crops, irrigation, disease, market..."
            className="flex-1 px-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors text-sm"
            disabled={loading}
          />
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || loading}
            className="w-12 h-12 rounded-xl bg-forest-600 hover:bg-forest-500 flex items-center justify-center transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            aria-label="Send message"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>

        <p className="text-xs text-gray-700 text-center mt-2">
          ⚠️ AI advice is for decision-support only. Consult agricultural experts before taking action.
        </p>
      </div>
    </div>
  );
}
