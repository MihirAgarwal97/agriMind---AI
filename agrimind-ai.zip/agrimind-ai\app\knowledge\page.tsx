"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, BookOpen, Tag, ChevronRight } from "lucide-react";
import { KNOWLEDGE_BASE } from "@/lib/demo/demoData";
import { SectionTitle } from "@/components/ui/SharedComponents";

const CATEGORIES = ["All", "Crop Management", "Disease Management", "Irrigation", "Pest Management", "Soil", "Weather", "Fertilization", "Harvesting"];

export default function KnowledgePage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [expanded, setExpanded] = useState<string | null>(null);

  const filtered = KNOWLEDGE_BASE.filter((item) => {
    const matchesCat = category === "All" || item.category === category;
    const matchesQuery =
      query === "" ||
      item.title.toLowerCase().includes(query.toLowerCase()) ||
      item.summary.toLowerCase().includes(query.toLowerCase()) ||
      item.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()));
    return matchesCat && matchesQuery;
  });

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-4xl mx-auto">
        <SectionTitle
          badge="RAG Knowledge Base"
          title="Agricultural Knowledge Intelligence"
          subtitle="AgriMind retrieves relevant knowledge articles before generating recommendations. This is our RAG (Retrieval-Augmented Generation) knowledge base."
        />

        {/* RAG explanation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 p-4 rounded-xl border border-blue-800/30 bg-blue-900/15 text-sm text-gray-400"
        >
          <strong className="text-blue-400">How RAG works in AgriMind:</strong> When you submit a farm analysis, AgriMind first retrieves the most relevant knowledge articles from this database using semantic search. These articles are then provided as context to IBM Granite, which grounds its recommendations in verified agricultural knowledge rather than hallucinating.
        </motion.div>

        {/* Search */}
        <div className="mb-6 space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search knowledge base..."
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-forest-950/60 border border-forest-800/50 text-white placeholder-gray-600 focus:outline-none focus:border-forest-600 transition-colors"
            />
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  category === cat
                    ? "bg-forest-600/20 border border-forest-600/50 text-forest-300"
                    : "border border-forest-900/50 text-gray-500 hover:text-gray-300 hover:border-forest-800"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        <div className="space-y-3">
          <p className="text-xs text-gray-600">{filtered.length} articles found</p>
          {filtered.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 overflow-hidden"
            >
              <button
                onClick={() => setExpanded(expanded === item.id ? null : item.id)}
                className="w-full text-left p-5"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs px-2 py-0.5 rounded bg-forest-900/60 text-forest-400 border border-forest-800/40">
                        {item.category}
                      </span>
                      <span className="text-xs text-gray-600">Relevance: {item.relevanceScore}%</span>
                    </div>
                    <h3 className="font-semibold text-white text-sm mb-1">{item.title}</h3>
                    <p className="text-gray-400 text-xs leading-relaxed">{item.summary}</p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {item.tags.slice(0, 4).map((tag) => (
                        <span key={tag} className="text-xs px-1.5 py-0.5 rounded bg-forest-950/80 text-forest-600 border border-forest-900/40">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 text-gray-600 flex-shrink-0 transition-transform mt-1 ${
                      expanded === item.id ? "rotate-90" : ""
                    }`}
                  />
                </div>
              </button>

              <AnimatePresence>
                {expanded === item.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-5 pb-5 pt-0 border-t border-forest-900/40">
                      <p className="text-gray-300 text-sm leading-relaxed mt-3">{item.content}</p>
                      <div className="mt-3 text-xs text-gray-600">
                        <strong className="text-forest-600">Source:</strong> AgriMind Agricultural Knowledge Base — Demo content based on agricultural best practices.
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}

          {filtered.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No articles found matching your search.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
