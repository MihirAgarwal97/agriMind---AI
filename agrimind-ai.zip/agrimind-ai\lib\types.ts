// Types for AgriMind AI

export interface FarmData {
  location: string;
  farmSize: string;
  soilType: string;
  irrigationType: string;
  crop: string;
  cropVariety: string;
  cropAge: string;
  plantingDate: string;
  problem: string;
  leafColor: string;
  symptoms: string;
  recentWeather: string;
  notes: string;
  budget: string;
  expectedYield: string;
  primaryGoal: string;
  image?: File | null;
}

export interface AgentResponse {
  agent: string;
  status: "idle" | "analyzing" | "complete" | "error";
  confidence: number;
  analysis: string;
  recommendations: string[];
  keyFindings?: string[];
}

export interface AnalysisResult {
  farmId: string;
  timestamp: string;
  location: string;
  crop: string;
  farmSize: string;
  cropAge: string;
  scores: {
    cropHealth: number;
    waterStatus: string;
    diseaseRisk: string;
    weatherRisk: string;
    marketOpportunity: string;
  };
  agentResponses: {
    crop: AgentResponse & { keyFindings: string[] };
    weather: AgentResponse & { weatherData: WeatherData };
    disease: AgentResponse & { possibleIssues: DiseaseIssue[] };
    market: AgentResponse & { marketData: MarketData };
  };
  graniteSynthesis: {
    summary: string;
    confidence: number;
    evidenceSources: string[];
    riskLevel: string;
    urgency: string;
  };
  actionPlan: ActionPlanItem[];
  weatherForecast: WeatherForecastDay[];
}

export interface WeatherData {
  temp: number;
  humidity: number;
  rainProb: number;
  windSpeed: number;
  soilMoisture: number;
}

export interface DiseaseIssue {
  name: string;
  probability: number;
  severity: string;
}

export interface MarketData {
  currentPrice: number;
  trend: string;
  harvestWindow: string;
  expectedRevenue: string;
  inputCostRemaining: string;
}

export interface ActionPlanItem {
  day: number;
  title: string;
  description: string;
  priority: "High" | "Medium" | "Low";
  category: string;
  details: string;
}

export interface WeatherForecastDay {
  day: string;
  temp: number;
  rain: number;
  humidity: number;
  icon: string;
}

export interface KnowledgeItem {
  id: string;
  category: string;
  title: string;
  summary: string;
  content: string;
  tags: string[];
  relevanceScore: number;
}

export type AgentStatus = "idle" | "analyzing" | "complete" | "error";

export interface AgentNode {
  id: string;
  name: string;
  icon: string;
  color: string;
  status: AgentStatus;
  lastAnalysis?: string;
  confidence?: number;
  tasks?: string[];
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  structured?: {
    answer: string;
    action: string;
    why: string;
    risk: string;
    nextStep: string;
    sources?: string[];
  };
}
