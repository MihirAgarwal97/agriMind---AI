import { DEMO_ANALYSIS_RESULT, KNOWLEDGE_BASE } from "@/lib/demo/demoData";
import type { FarmData, AnalysisResult, KnowledgeItem } from "@/lib/types";

// Simulated delay for realistic AI analysis experience
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// RAG: Retrieve relevant knowledge
export function retrieveKnowledge(query: string, crop: string = ""): KnowledgeItem[] {
  const terms = query.toLowerCase().split(" ").concat(crop.toLowerCase().split(" "));
  return KNOWLEDGE_BASE.filter((item) => {
    const searchText = `${item.title} ${item.summary} ${item.tags.join(" ")}`.toLowerCase();
    return terms.some((term) => term.length > 3 && searchText.includes(term));
  }).sort((a, b) => b.relevanceScore - a.relevanceScore);
}

// Main analysis function — uses demo data with IBM Granite simulation
export async function analyzeFarm(farmData: FarmData): Promise<AnalysisResult> {
  // In a real implementation, this would call IBM Granite via IBM Bob Agent
  // For demo: return structured demo result with farm-specific customizations
  await delay(100);

  const result = {
    ...DEMO_ANALYSIS_RESULT,
    location: farmData.location || DEMO_ANALYSIS_RESULT.location,
    crop: farmData.crop || DEMO_ANALYSIS_RESULT.crop,
    farmSize: `${farmData.farmSize || "2"} acres`,
    cropAge: `${farmData.cropAge || "35"} days`,
    timestamp: new Date().toISOString(),
  };

  return result as AnalysisResult;
}

// Simulated IBM Granite chat response
export async function getAgriAdvice(
  question: string,
  farmContext?: Partial<FarmData>
): Promise<{
  answer: string;
  action: string;
  why: string;
  risk: string;
  nextStep: string;
  sources: string[];
}> {
  await delay(800);

  // Retrieve relevant knowledge
  const knowledgeItems = retrieveKnowledge(question, farmContext?.crop || "tomato");

  // Simple rule-based response matching for demo
  const q = question.toLowerCase();

  if (q.includes("yellow") || q.includes("yellowing")) {
    return {
      answer:
        "Yellowing tomato leaves can indicate nitrogen or magnesium deficiency, water stress, or early disease. Lower leaf yellowing is most commonly a nutritional issue.",
      action:
        "Inspect lower leaves closely for pattern (tip vs. interveinal vs. uniform). Check soil moisture. Consider a foliar micronutrient assessment.",
      why: "Nitrogen drives chlorophyll production. Deficiency causes chlorophyll breakdown, resulting in yellowing — typically in older, lower leaves first.",
      risk:
        "If caused by Fusarium wilt, the crop may be at serious risk. Confirm by checking stem for brown vascular tissue before assuming nutritional cause.",
      nextStep:
        "Conduct visual inspection today. If nutrient deficiency is confirmed by pattern, apply approved foliar spray per label guidance. Consult agricultural expert if symptoms spread.",
      sources: knowledgeItems.slice(0, 3).map((k) => k.title),
    };
  }

  if (q.includes("irrigat") || q.includes("water")) {
    return {
      answer:
        "For tomato at vegetative stage in semi-arid conditions, drip irrigation of 45-60 minutes daily is recommended. Schedule irrigation between 6-8 AM to minimize evaporation.",
      action:
        "Check soil moisture at 6-inch depth. Adjust irrigation duration based on soil moisture reading. Ensure all drip emitters are functioning.",
      why: "Consistent soil moisture in the 60-80% field capacity range supports optimal nutrient uptake and prevents both drought stress and waterlogging.",
      risk:
        "Over-irrigation can cause root rot and leach nutrients. Under-irrigation during flowering causes fruit drop. Both extremes are harmful.",
      nextStep:
        "Measure soil moisture today. Adjust irrigation schedule. Check for clogged drip emitters. Consider installing a soil moisture sensor for precision irrigation.",
      sources: knowledgeItems.slice(0, 2).map((k) => k.title),
    };
  }

  if (q.includes("fertilizer") || q.includes("nutrient")) {
    return {
      answer:
        "Tomato at 35 days needs balanced NPK. Nitrogen supports vegetative growth, phosphorus supports roots and flowering, potassium supports fruit development. Magnesium is critical for chlorophyll.",
      action:
        "Before applying any fertilizer, confirm current soil nutrient status through a soil test or visual diagnosis. Apply only what is needed.",
      why: "Over-fertilization, especially with nitrogen, can cause vegetative excess (more leaves, less fruit), salt burn, and environmental contamination.",
      risk:
        "Applying wrong nutrients wastes budget and can harm the crop. Chemical fertilizers should follow label rates and local agricultural guidance.",
      nextStep:
        "Get a simple soil test from your local Krishi Vigyan Kendra. Apply fertilizer based on actual soil needs, not general prescription.",
      sources: knowledgeItems.slice(0, 2).map((k) => k.title),
    };
  }

  if (q.includes("yield") || q.includes("production")) {
    return {
      answer:
        "Tomato yield of 25-35 tonnes/hectare is achievable with good management in Rajasthan. Key factors: disease prevention, timely irrigation, adequate nutrition, and proper harvest timing.",
      action:
        "Focus on preventive management rather than reactive treatment. Maintain crop health through the vegetative and flowering stages for maximum yield.",
      why: "Stress at any stage, especially during flowering (35-55 days), directly reduces fruit set and final yield. Early intervention prevents compounding issues.",
      risk:
        "Yield estimates are highly variable based on weather, pest pressure, and market conditions. Do not make financial decisions based solely on theoretical yield.",
      nextStep:
        "Create a crop management calendar. Set weekly field monitoring reminders. Use AgriMind analysis regularly to track crop health trends.",
      sources: knowledgeItems.slice(0, 2).map((k) => k.title),
    };
  }

  // Default response
  return {
    answer:
      "AgriMind AI can help you with crop health assessment, irrigation planning, pest and disease identification, and market considerations for your farm.",
    action:
      "For the most accurate advice, use the Farm Analyzer to input your specific farm data. This allows the multi-agent system to provide personalized recommendations.",
    why: "General advice may not account for your specific soil, climate, crop variety, and current conditions. Personalized analysis provides more actionable guidance.",
    risk: "Always verify AI recommendations with local agricultural experts and follow official guidance for any chemical application.",
    nextStep:
      "Go to Farm Analyzer, load the demo farm, or enter your own farm data to receive a complete AI-powered farming intelligence report.",
    sources: knowledgeItems.slice(0, 2).map((k) => k.title),
  };
}

export const AGENT_ANALYSIS_STEPS = [
  { id: "reading", label: "Reading farm information", duration: 600 },
  { id: "rag", label: "Consulting agricultural knowledge base", duration: 900 },
  { id: "crop", label: "Crop Agent analyzing crop stage & health", duration: 1200 },
  { id: "weather", label: "Weather Agent analyzing conditions & irrigation", duration: 1000 },
  { id: "disease", label: "Disease Agent checking symptoms & risks", duration: 1100 },
  { id: "market", label: "Market Agent evaluating market factors", duration: 800 },
  { id: "granite", label: "IBM Granite synthesizing recommendations", duration: 1500 },
  { id: "complete", label: "Analysis complete — preparing your report", duration: 500 },
];
