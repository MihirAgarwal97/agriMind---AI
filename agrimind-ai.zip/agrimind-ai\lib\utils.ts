import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(n: number): string {
  if (n >= 100000) return `${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return n.toString();
}

export function getRiskColor(risk: string): string {
  const r = risk.toLowerCase();
  if (r.includes("low")) return "text-green-400";
  if (r.includes("medium") || r.includes("moderate")) return "text-yellow-400";
  if (r.includes("high")) return "text-red-400";
  return "text-gray-400";
}

export function getScoreColor(score: number): string {
  if (score >= 80) return "#22c55e";
  if (score >= 60) return "#eab308";
  if (score >= 40) return "#f97316";
  return "#ef4444";
}

export function getPriorityColor(priority: string): string {
  if (priority === "High") return "text-red-400 bg-red-400/10 border-red-400/30";
  if (priority === "Medium") return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
  return "text-green-400 bg-green-400/10 border-green-400/30";
}

export function getCategoryIcon(category: string): string {
  const icons: Record<string, string> = {
    diagnosis: "🔍",
    irrigation: "💧",
    nutrition: "🌿",
    treatment: "💊",
    monitoring: "👁️",
    review: "📊",
  };
  return icons[category] || "📌";
}
