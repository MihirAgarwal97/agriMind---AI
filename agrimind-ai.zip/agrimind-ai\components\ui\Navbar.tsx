"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Sprout, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/dashboard", label: "Farm Intelligence" },
  { href: "/agents", label: "AI Agents" },
  { href: "/disease", label: "Disease Detection" },
  { href: "/market", label: "Market Insights" },
  { href: "/architecture", label: "Architecture" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-[#030b06]/90 backdrop-blur-xl border-b border-forest-900/50 shadow-lg shadow-black/20"
          : "bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-forest-500 to-emerald-600 flex items-center justify-center shadow-lg group-hover:shadow-forest-500/30 transition-shadow">
              <Sprout className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-lg text-white">
              Agri<span className="text-forest-400">Mind</span>{" "}
              <span className="text-xs font-medium text-forest-500 ml-0.5">AI</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                  pathname === link.href
                    ? "text-forest-400 bg-forest-400/10"
                    : "text-gray-400 hover:text-forest-300 hover:bg-forest-900/50"
                )}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/analyze"
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-forest-600 hover:bg-forest-500 text-white text-sm font-medium transition-all duration-200 shadow-lg shadow-forest-900/30 hover:shadow-forest-500/20"
            >
              <Zap className="w-4 h-4" />
              Launch AI Advisor
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-forest-900/50 transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#030b06]/95 backdrop-blur-xl border-b border-forest-900/50"
          >
            <div className="px-4 py-4 space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "block px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    pathname === link.href
                      ? "text-forest-400 bg-forest-400/10"
                      : "text-gray-400 hover:text-forest-300 hover:bg-forest-900/50"
                  )}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/analyze"
                onClick={() => setMobileOpen(false)}
                className="flex items-center justify-center gap-2 w-full mt-2 px-4 py-2.5 rounded-lg bg-forest-600 text-white text-sm font-medium"
              >
                <Zap className="w-4 h-4" />
                Launch AI Advisor
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
