"use client";

import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Brain, DollarSign, BarChart3 } from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area
} from "recharts";
import { DEMO_MARKET } from "@/lib/demo/demoData";
import { DemoBadge } from "@/components/ui/SharedComponents";

export default function MarketPage() {
  const { priceHistory, insight, costAnalysis } = DEMO_MARKET;

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-5xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-bold text-white">Market Intelligence</h1>
            <DemoBadge />
          </div>
          <p className="text-gray-400">
            Crop: <span className="text-forest-400 font-medium">{DEMO_MARKET.crop}</span> •
            Location: <span className="text-gray-300">{DEMO_MARKET.location}</span>
          </p>
        </motion.div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Current Price", value: `₹${DEMO_MARKET.currentPrice}/kg`, change: `+₹${DEMO_MARKET.weeklyChange}/kg`, up: true, icon: DollarSign, color: "text-forest-400", border: "border-forest-800/40" },
            { label: "Market Trend", value: DEMO_MARKET.trend, change: "7-day trend", up: true, icon: TrendingUp, color: "text-green-400", border: "border-green-800/40" },
            { label: "Harvest Window", value: "May–June", change: "~45–60 days", up: null, icon: BarChart3, color: "text-yellow-400", border: "border-yellow-800/40" },
            { label: "Expected Revenue", value: costAnalysis.expectedRevenue, change: `ROI: ${costAnalysis.roi}`, up: true, icon: TrendingUp, color: "text-purple-400", border: "border-purple-800/40" },
          ].map((card, i) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`rounded-xl border ${card.border} bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-4`}
              >
                <Icon className={`w-5 h-5 mb-2 ${card.color}`} />
                <div className={`text-xl font-bold ${card.color}`}>{card.value}</div>
                <div className="text-xs text-gray-500 mt-0.5">{card.label}</div>
                <div className={`text-xs mt-1 ${card.up === true ? "text-green-500" : card.up === false ? "text-red-500" : "text-gray-500"}`}>
                  {card.up !== null && (card.up ? "↑" : "↓")} {card.change}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Price chart */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white">Tomato Price History — Jaipur Mandi</h3>
            <DemoBadge />
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={priceHistory} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="date" tick={{ fill: "#6b7280", fontSize: 11 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 11 }} unit="₹" />
              <Tooltip
                contentStyle={{ background: "#071a0e", border: "1px solid rgba(34,197,94,0.2)", borderRadius: "8px", color: "#fff" }}
                formatter={(v) => [`₹${v}/kg`, "Price"]}
              />
              <Area type="monotone" dataKey="price" stroke="#22c55e" fill="url(#priceGrad)" strokeWidth={2.5} dot={{ fill: "#22c55e", r: 4 }} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* AI Insight */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="rounded-2xl border border-blue-800/30 bg-gradient-to-br from-blue-900/20 to-blue-950/20 p-6 mb-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <Brain className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-white">AI Market Insight</h3>
            <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/20">IBM Granite</span>
          </div>
          <p className="text-gray-300 leading-relaxed">{insight}</p>
          <p className="text-xs text-gray-600 mt-3 italic">
            ⚠️ Market data is simulated for demo purposes. Use actual Agmarknet or local mandi data for real decisions.
          </p>
        </motion.div>

        {/* Cost analysis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-6"
        >
          <h3 className="font-bold text-white mb-4">Cost-Revenue Analysis</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Input Cost (remaining)", value: `₹${costAnalysis.inputCost.toLocaleString()}`, color: "text-red-400" },
              { label: "Expected Revenue", value: costAnalysis.expectedRevenue, color: "text-forest-400" },
              { label: "Projected Profit", value: `₹${costAnalysis.projectedProfit.toLocaleString()}`, color: "text-green-400" },
              { label: "Expected ROI", value: costAnalysis.roi, color: "text-purple-400" },
            ].map((item) => (
              <div key={item.label} className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                <div className={`text-xl font-bold ${item.color}`}>{item.value}</div>
                <div className="text-xs text-gray-500 mt-1">{item.label}</div>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-600 mt-4 text-center">
            Based on demo market data and assumed input costs. Actual results may vary significantly.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
