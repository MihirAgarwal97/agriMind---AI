"use client";

import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Sprout, CloudRain, Bug, TrendingUp, Brain, Activity, CheckCircle2 } from "lucide-react";
import { SectionTitle } from "@/components/ui/SharedComponents";

const AGENTS = [
  {
    id: "crop",
    name: "Crop Intelligence Agent",
    icon: Sprout,
    color: "#22c55e",
    bgColor: "rgba(34,197,94,0.1)",
    borderColor: "rgba(34,197,94,0.3)",
    description: "Analyzes crop stage, soil context, nutrition requirements and growth monitoring.",
    tasks: ["Crop stage detection", "Nutrient requirement calculation", "Growth trend analysis", "Soil compatibility check"],
    confidence: 82,
    lastAnalysis: "Jaipur Tomato — 35 days",
    pos: { x: 20, y: 20 },
  },
  {
    id: "weather",
    name: "Weather & Irrigation Agent",
    icon: CloudRain,
    color: "#38bdf8",
    bgColor: "rgba(56,189,248,0.1)",
    borderColor: "rgba(56,189,248,0.3)",
    description: "Monitors weather patterns, rainfall probability, temperature stress and irrigation scheduling.",
    tasks: ["Temperature monitoring", "Rain probability analysis", "Irrigation scheduling", "Evapotranspiration calculation"],
    confidence: 88,
    lastAnalysis: "Jaipur — 40°C, Rain in 3 days",
    pos: { x: 76, y: 20 },
  },
  {
    id: "disease",
    name: "Pest & Disease Agent",
    icon: Bug,
    color: "#fb923c",
    bgColor: "rgba(251,146,60,0.1)",
    borderColor: "rgba(251,146,60,0.3)",
    description: "Identifies possible diseases, pest risks, and preventive actions from symptoms.",
    tasks: ["Symptom pattern matching", "Disease probability scoring", "Pest risk assessment", "Treatment recommendation"],
    confidence: 71,
    lastAnalysis: "Yellowing leaves — N deficiency likely",
    pos: { x: 20, y: 72 },
  },
  {
    id: "market",
    name: "Market Intelligence Agent",
    icon: TrendingUp,
    color: "#a78bfa",
    bgColor: "rgba(167,139,250,0.1)",
    borderColor: "rgba(167,139,250,0.3)",
    description: "Tracks market trends, optimizes harvest timing, and analyzes cost-revenue factors.",
    tasks: ["Price trend analysis", "Harvest timing optimization", "Cost-benefit calculation", "Market opportunity scoring"],
    confidence: 65,
    lastAnalysis: "Tomato ₹18/kg — Rising trend",
    pos: { x: 76, y: 72 },
  },
];

export default function AgentsPage() {
  const [activeAgent, setActiveAgent] = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [completedAgents, setCompletedAgents] = useState<string[]>([]);
  const svgRef = useRef<SVGSVGElement>(null);

  const runDemo = async () => {
    setRunning(true);
    setCompletedAgents([]);
    const order = ["crop", "weather", "disease", "market"];
    for (const id of order) {
      setActiveAgent(id);
      await new Promise((r) => setTimeout(r, 1800));
      setCompletedAgents((prev) => [...prev, id]);
    }
    setActiveAgent("granite");
    await new Promise((r) => setTimeout(r, 1500));
    setActiveAgent(null);
    setRunning(false);
  };

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-6xl mx-auto">
        <SectionTitle
          badge="AI Agent Network"
          title="Multi-Agent Orchestration System"
          subtitle="Watch how four specialized AI agents collaborate to analyze your farm data, each contributing unique expertise before IBM Granite synthesizes the final recommendation."
        />

        {/* Run demo button */}
        <div className="flex justify-center mb-8">
          <button
            onClick={runDemo}
            disabled={running}
            className="flex items-center gap-3 px-6 py-3 rounded-xl bg-forest-600 hover:bg-forest-500 text-white font-semibold transition-all disabled:opacity-60 shadow-lg shadow-forest-900/40"
          >
            <Activity className="w-5 h-5" />
            {running ? "Agents Running..." : "Run Agent Demo"}
            {running && (
              <span className="flex gap-1">
                {[0,1,2].map(i => (
                  <motion.span key={i} className="w-1.5 h-1.5 rounded-full bg-white"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.2 }}
                  />
                ))}
              </span>
            )}
          </button>
        </div>

        {/* Agent Network Visualization */}
        <div className="relative rounded-3xl border border-forest-900/60 bg-gradient-to-br from-[#071a0e]/80 to-[#030b06]/80 overflow-hidden mb-8" style={{ minHeight: 420 }}>
          {/* SVG connection lines */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none" ref={svgRef}>
            {AGENTS.map((agent) => {
              const isActive = activeAgent === agent.id || completedAgents.includes(agent.id);
              const cx = agent.pos.x + 2;
              const cy = agent.pos.y + 6;
              return (
                <g key={agent.id}>
                  <line
                    x1={cx} y1={cy}
                    x2="50" y2="50"
                    stroke={isActive ? agent.color : "rgba(255,255,255,0.04)"}
                    strokeWidth={isActive ? "0.4" : "0.2"}
                    strokeDasharray={isActive ? "2 1.5" : "none"}
                    style={{ transition: "all 0.5s ease" }}
                  />
                  {isActive && (
                    <>
                      <circle r="0.8" fill={agent.color} opacity="0.8">
                        <animateMotion dur="1.2s" repeatCount="indefinite" path={`M ${cx} ${cy} L 50 50`} />
                      </circle>
                      <circle r="0.8" fill={agent.color} opacity="0.5">
                        <animateMotion dur="1.2s" repeatCount="indefinite" begin="0.6s" path={`M ${cx} ${cy} L 50 50`} />
                      </circle>
                    </>
                  )}
                </g>
              );
            })}
          </svg>

          {/* Agent cards positioned in corners */}
          <div className="relative h-full p-6" style={{ minHeight: 420 }}>
            {AGENTS.map((agent) => {
              const Icon = agent.icon;
              const isActive = activeAgent === agent.id;
              const isDone = completedAgents.includes(agent.id);
              const pos = agent.pos;

              return (
                <motion.div
                  key={agent.id}
                  animate={isActive ? { scale: [1, 1.04, 1] } : { scale: 1 }}
                  transition={{ duration: 1, repeat: isActive ? Infinity : 0 }}
                  onClick={() => setActiveAgent(activeAgent === agent.id ? null : agent.id)}
                  className="absolute cursor-pointer"
                  style={{
                    left: `${pos.x}%`,
                    top: `${pos.y}%`,
                    width: "22%",
                  }}
                >
                  <div
                    className="rounded-2xl p-4 border transition-all"
                    style={{
                      background: isActive || isDone ? agent.bgColor : "rgba(13,41,24,0.4)",
                      borderColor: isActive || isDone ? agent.borderColor : "rgba(255,255,255,0.06)",
                      boxShadow: isActive ? `0 0 30px ${agent.color}30` : "none",
                    }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center"
                        style={{ background: `${agent.color}20` }}
                      >
                        <Icon className="w-4 h-4" style={{ color: isActive || isDone ? agent.color : "#4b5563" }} />
                      </div>
                      {isDone && !isActive && <CheckCircle2 className="w-4 h-4 text-green-500" />}
                      {isActive && (
                        <motion.span className="w-2 h-2 rounded-full" style={{ backgroundColor: agent.color }}
                          animate={{ opacity: [0.5, 1, 0.5] }} transition={{ duration: 1, repeat: Infinity }}
                        />
                      )}
                    </div>
                    <div className="text-xs font-semibold text-white leading-tight">{agent.name}</div>
                    <div className="text-xs mt-1" style={{ color: isActive || isDone ? agent.color : "#6b7280" }}>
                      {isActive ? "Analyzing..." : isDone ? `Done • ${agent.confidence}%` : "Standby"}
                    </div>
                  </div>
                </motion.div>
              );
            })}

            {/* Central orchestrator */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                animate={activeAgent === "granite" ? { scale: [1, 1.08, 1] } : { scale: 1 }}
                transition={{ duration: 1, repeat: activeAgent === "granite" ? Infinity : 0 }}
                className="rounded-2xl p-4 text-center"
                style={{
                  background: activeAgent === "granite" ? "rgba(59,130,246,0.2)" : "rgba(30,64,175,0.1)",
                  border: `1px solid ${activeAgent === "granite" ? "rgba(59,130,246,0.5)" : "rgba(59,130,246,0.2)"}`,
                  boxShadow: activeAgent === "granite" ? "0 0 40px rgba(59,130,246,0.3)" : "none",
                  width: 120,
                }}
              >
                <Brain className={`w-8 h-8 mx-auto mb-1 ${activeAgent === "granite" ? "text-blue-400" : "text-blue-800"}`} />
                <div className="text-xs font-bold text-blue-300">IBM Granite</div>
                <div className="text-[10px] text-blue-600">Synthesis</div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Agent details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {AGENTS.map((agent, i) => {
            const Icon = agent.icon;
            const isDone = completedAgents.includes(agent.id);
            const isActive = activeAgent === agent.id;
            return (
              <motion.div
                key={agent.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-5 border transition-all"
                style={{
                  background: "rgba(13,41,24,0.5)",
                  borderColor: isDone || isActive ? agent.borderColor : "rgba(255,255,255,0.06)",
                }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4" style={{ color: agent.color }} />
                    <span className="font-semibold text-white text-sm">{agent.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-0.5 rounded" style={{ background: `${agent.color}15`, color: agent.color }}>
                      {agent.confidence}% conf.
                    </span>
                  </div>
                </div>
                <p className="text-xs text-gray-400 mb-3">{agent.description}</p>
                <div className="mb-3">
                  <div className="text-xs text-gray-600 mb-1.5">Capability Tasks:</div>
                  <div className="grid grid-cols-2 gap-1">
                    {agent.tasks.map((t) => (
                      <div key={t} className="text-xs text-gray-500 flex items-center gap-1">
                        <span className="w-1 h-1 rounded-full flex-shrink-0" style={{ backgroundColor: agent.color }} />
                        {t}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="text-xs text-gray-600 border-t border-white/5 pt-2">
                  <strong>Last Analysis:</strong> {agent.lastAnalysis}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* IBM note */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-8 p-4 rounded-xl border border-blue-800/30 bg-blue-900/10 text-center"
        >
          <p className="text-blue-400 text-sm font-medium mb-1">Powered by IBM Granite + IBM Bob Agent</p>
          <p className="text-gray-500 text-xs">
            In production, each agent would invoke IBM Granite via IBM Bob Agent API with domain-specific prompts and RAG context.
            The orchestrator synthesizes all agent outputs into a unified recommendation.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
