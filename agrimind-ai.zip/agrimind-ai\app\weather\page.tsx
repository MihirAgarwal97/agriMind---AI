"use client";

import { motion } from "framer-motion";
import { Cloud, Droplets, Wind, Eye, Thermometer, Sun, Brain } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar
} from "recharts";
import { DEMO_WEATHER } from "@/lib/demo/demoData";
import { DemoBadge, SectionTitle } from "@/components/ui/SharedComponents";

const weatherCards = [
  { label: "Temperature", value: `${DEMO_WEATHER.current.temp}°C`, sub: `Feels ${DEMO_WEATHER.current.feelsLike}°C`, icon: Thermometer, color: "text-orange-400", border: "border-orange-800/30" },
  { label: "Humidity", value: `${DEMO_WEATHER.current.humidity}%`, sub: "Relative humidity", icon: Droplets, color: "text-sky-400", border: "border-sky-800/30" },
  { label: "Rain Probability", value: `${DEMO_WEATHER.current.rainProb}%`, sub: "Next 24 hours", icon: Cloud, color: "text-blue-400", border: "border-blue-800/30" },
  { label: "Wind Speed", value: `${DEMO_WEATHER.current.windSpeed} km/h`, sub: `Direction: ${DEMO_WEATHER.current.windDirection}`, icon: Wind, color: "text-gray-400", border: "border-gray-800/30" },
  { label: "UV Index", value: `${DEMO_WEATHER.current.uvIndex}`, sub: "Very High", icon: Sun, color: "text-yellow-400", border: "border-yellow-800/30" },
  { label: "Soil Moisture", value: `${DEMO_WEATHER.current.soilMoisture}%`, sub: "Below optimal", icon: Droplets, color: "text-green-400", border: "border-green-800/30" },
];

export default function WeatherPage() {
  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-5xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-bold text-white">Weather & Irrigation</h1>
            <DemoBadge />
          </div>
          <p className="text-gray-400">Real-time weather intelligence and AI irrigation recommendations</p>
        </motion.div>

        {/* Current conditions */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
          {weatherCards.map((card, i) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className={`rounded-xl border ${card.border} bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-4 text-center`}
              >
                <Icon className={`w-5 h-5 mx-auto mb-2 ${card.color}`} />
                <div className={`text-xl font-bold ${card.color}`}>{card.value}</div>
                <div className="text-xs text-gray-500 mt-0.5">{card.label}</div>
                <div className="text-xs text-gray-600 mt-0.5">{card.sub}</div>
              </motion.div>
            );
          })}
        </div>

        {/* 24-hour temp chart */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white">24-Hour Temperature & Rain Forecast</h3>
            <DemoBadge />
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={DEMO_WEATHER.hourly} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f97316" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="rainGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="hour" tick={{ fill: "#6b7280", fontSize: 11 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 11 }} />
              <Tooltip
                contentStyle={{ background: "#071a0e", border: "1px solid rgba(34,197,94,0.2)", borderRadius: "8px", color: "#fff" }}
              />
              <Area type="monotone" dataKey="temp" stroke="#f97316" fill="url(#tempGrad)" strokeWidth={2} name="Temp (°C)" />
              <Area type="monotone" dataKey="rain" stroke="#38bdf8" fill="url(#rainGrad)" strokeWidth={2} name="Rain (%)" />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* AI Irrigation Recommendation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="rounded-2xl border border-blue-800/30 bg-gradient-to-br from-blue-900/20 to-blue-950/20 p-6 mb-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-white">AI Irrigation Recommendation</h3>
            <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/20">IBM Granite</span>
          </div>
          <p className="text-gray-300 mb-4 leading-relaxed">{DEMO_WEATHER.irrigation.recommendation}</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Recommended Window", value: DEMO_WEATHER.irrigation.window, color: "text-forest-400" },
              { label: "Duration", value: DEMO_WEATHER.irrigation.duration, color: "text-forest-400" },
              { label: "Water Saving Score", value: `${DEMO_WEATHER.irrigation.waterSavingScore}%`, color: "text-blue-400" },
              { label: "Next Rain", value: `In ${DEMO_WEATHER.irrigation.nextRainIn}`, color: "text-sky-400" },
            ].map((item) => (
              <div key={item.label} className="p-3 rounded-xl bg-white/5 border border-white/5">
                <div className={`text-lg font-bold ${item.color}`}>{item.value}</div>
                <div className="text-xs text-gray-500 mt-0.5">{item.label}</div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Efficiency metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-6"
          >
            <h3 className="font-bold text-white mb-4">Irrigation Efficiency</h3>
            <div className="space-y-4">
              {[
                { label: "Water Saving Score", value: DEMO_WEATHER.irrigation.waterSavingScore, color: "#22c55e" },
                { label: "Irrigation Efficiency", value: DEMO_WEATHER.irrigation.efficiency, color: "#38bdf8" },
                { label: "Soil Moisture", value: DEMO_WEATHER.current.soilMoisture, color: "#f97316" },
              ].map((item) => (
                <div key={item.label}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-gray-400">{item.label}</span>
                    <span className="font-medium text-white">{item.value}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-gray-800 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${item.value}%` }}
                      transition={{ duration: 1, delay: 0.5 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-6"
          >
            <h3 className="font-bold text-white mb-4">Rain Probability (7 days)</h3>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={[
                { day: "Mon", rain: 5 }, { day: "Tue", rain: 3 }, { day: "Wed", rain: 20 },
                { day: "Thu", rain: 40 }, { day: "Fri", rain: 60 }, { day: "Sat", rain: 35 }, { day: "Sun", rain: 10 }
              ]}>
                <XAxis dataKey="day" tick={{ fill: "#6b7280", fontSize: 11 }} />
                <Tooltip contentStyle={{ background: "#071a0e", border: "1px solid rgba(34,197,94,0.2)", borderRadius: "8px", color: "#fff" }} />
                <Bar dataKey="rain" fill="#38bdf8" fillOpacity={0.7} radius={[4, 4, 0, 0]} name="Rain %" />
              </BarChart>
            </ResponsiveContainer>
            <p className="text-xs text-gray-500 mt-2 text-center">Higher rain probability later in the week — consider adjusting irrigation schedule</p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
