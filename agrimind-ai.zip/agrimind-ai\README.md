# 🌱 AgriMind AI — Intelligence for Every Acre

> **Hackathon Project** — IBM Granite + IBM Bob Agent + RAG + Multi-Agent AI

A complete, production-quality AI-powered agricultural decision-support system built for the **Smart AI Farming Advice** hackathon challenge.

---

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🎯 Demo Flow (for Judges)

1. **Open** `http://localhost:3000` — see the hero with animated AI agent network
2. **Click** "Launch AI Advisor" → goes to `/analyze`
3. **Click** "Load Demo Farm (Jaipur Tomato)" — loads all demo data
4. **Click** "Run AI Farm Analysis" → animated multi-agent analysis screen
5. **Watch** Crop Agent → Weather Agent → Disease Agent → Market Agent → IBM Granite synthesize
6. **See** full Farm Intelligence Report with 7-Day Action Plan
7. **Click** "Why this recommendation?" to see RAG evidence sources
8. **Navigate** to `/agents` to see the visual AI agent network
9. **Try** `/advisor` for AI chat questions like "Why are my tomato leaves yellow?"

---

## 📁 Project Structure

```
agrimind-ai/
├── app/
│   ├── page.tsx              # Landing page (hero, tech strip, problem, agents)
│   ├── analyze/page.tsx      # Multi-step farm analyzer form
│   ├── analysis/page.tsx     # Animated multi-agent analysis experience
│   ├── results/page.tsx      # Full farm intelligence report dashboard
│   ├── dashboard/page.tsx    # Farm overview dashboard
│   ├── agents/page.tsx       # AI agent network monitor
│   ├── advisor/page.tsx      # AI chat advisor
│   ├── weather/page.tsx      # Weather & irrigation intelligence
│   ├── disease/page.tsx      # Crop disease detection
│   ├── market/page.tsx       # Market intelligence
│   ├── knowledge/page.tsx    # RAG knowledge base browser
│   └── architecture/page.tsx # System architecture diagram
│
├── components/
│   ├── ui/
│   │   ├── Navbar.tsx          # Sticky navigation with mobile menu
│   │   └── SharedComponents.tsx # ScoreGauge, StatusBadge, Card, SectionTitle, etc.
│   └── ai/
│       └── AgriCanvas.tsx      # Canvas-based animated AI agent visualization
│
└── lib/
    ├── types.ts              # TypeScript interfaces
    ├── utils.ts              # Utility functions
    ├── ai/
    │   └── agriMind.ts       # AI service layer (IBM Granite adapter + RAG)
    └── demo/
        └── demoData.ts       # Complete demo dataset (no API required)
```

---

## 🛠 Technology Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 15 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS v4 |
| Animation | Framer Motion |
| Charts | Recharts |
| Icons | Lucide React |
| Visualization | HTML5 Canvas |
| AI (Production) | IBM Granite + IBM Bob Agent |
| AI (Demo) | Rule-based + structured demo data |

---

## 🤖 IBM Technology Integration

### IBM Granite
- **Role:** Foundation model for recommendation generation, reasoning, and synthesis
- **In Demo:** Simulated via structured rule-based responses and realistic demo output
- **Production Adapter:** `lib/ai/agriMind.ts` → swap demo functions for IBM Granite API calls

### IBM Bob Agent  
- **Role:** Agent orchestration, workflow management, multi-agent coordination
- **In Demo:** Simulated sequential agent pipeline with animated UI
- **Production Adapter:** Replace `AGENT_ANALYSIS_STEPS` loop with IBM Bob Agent workflow

### RAG (Retrieval-Augmented Generation)
- **Role:** Grounds AI recommendations in verified agricultural knowledge
- **Implementation:** `lib/demo/demoData.ts` → `KNOWLEDGE_BASE` (8 agricultural articles)
- **How it works:** `retrieveKnowledge()` does keyword-based retrieval; production uses semantic embeddings
- **UI:** Visible in `/knowledge` page and "Why this recommendation?" evidence section

---

## 🌾 Multi-Agent Architecture

```
Farmer Input
     ↓
AI Orchestrator (IBM Bob Agent)
     ↓
 ┌─────────────────────────────────┐
 │ 🌱 Crop Intelligence Agent      │  → Stage, nutrition, growth analysis
 │ 🌦 Weather & Irrigation Agent   │  → Climate, water, irrigation scheduling  
 │ 🐛 Pest & Disease Agent         │  → Symptoms, disease risk, prevention
 │ 💰 Market Intelligence Agent    │  → Prices, timing, cost-revenue
 └─────────────────────────────────┘
     ↓
RAG Knowledge Retrieval
     ↓
IBM Granite Synthesis
     ↓
Personalized Farm Intelligence Report
```

---

## ✅ What's Real vs. Simulated

### ✅ Fully Implemented
- Complete multi-step farm data collection UI
- Multi-agent architecture with visual orchestration
- Animated agent analysis sequence with realistic timing
- RAG knowledge base with 8 agricultural knowledge articles
- Structured AI response format (answer, action, why, risk, next step)
- 7-day action plan with categorized priorities
- Weather, disease, market intelligence UIs
- AI chat advisor with domain-aware responses
- Full responsive design (mobile → desktop)
- Accessibility (semantic HTML, keyboard nav, reduced motion)

### ⚠️ Simulated for Demo (No API Required)
- IBM Granite API calls → realistic demo output in `demoData.ts`
- Live weather data → static demo values (40°C, 28% humidity, Jaipur)
- Real market prices → demo price history chart
- Computer vision disease analysis → rule-based demo assessment
- Database persistence → sessionStorage

---

## 🔌 Adding Real APIs Later

All integration points are isolated in `lib/ai/agriMind.ts`:

```typescript
// Replace this demo function with IBM Granite API call:
export async function analyzeFarm(farmData: FarmData): Promise<AnalysisResult> {
  // TODO: Call IBM Granite via IBM Bob Agent API
  // const result = await ibmGraniteClient.generate({ prompt, context })
  return DEMO_ANALYSIS_RESULT; // ← swap this
}

// Replace this with real IBM Granite chat:
export async function getAgriAdvice(question: string) {
  // TODO: Call IBM Granite with RAG context
  return ruleBasedResponse(question); // ← swap this
}
```

---

## 📱 All Routes

| Route | Description |
|-------|-------------|
| `/` | Landing page with hero + agent overview |
| `/analyze` | Multi-step farm analyzer (4-step form) |
| `/analysis` | Animated multi-agent analysis sequence |
| `/results` | Full farm intelligence report |
| `/dashboard` | Farm overview dashboard |
| `/agents` | Visual AI agent network monitor |
| `/advisor` | AI chat farming advisor |
| `/weather` | Weather & irrigation intelligence |
| `/disease` | Crop disease detection (image upload) |
| `/market` | Market intelligence & price history |
| `/knowledge` | RAG agricultural knowledge base |
| `/architecture` | System architecture diagram |

---

## ⚠️ AI Safety Disclaimer

AgriMind AI provides decision-support recommendations and should not replace qualified agricultural professionals or local agricultural authorities. Disease and treatment recommendations are illustrative only. Always consult certified agronomists before applying any chemical treatment.
