"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouter } from "next/navigation";
import { CheckCircle2, Circle, Brain, Sprout, CloudRain, Bug, TrendingUp, Zap } from "lucide-react";
import { AGENT_ANALYSIS_STEPS } from "@/lib/ai/agriMind";
import { DEMO_FARM } from "@/lib/demo/demoData";

const AGENTS = [
  { id: "crop", label: "Crop Agent", icon: Sprout, color: "#22c55e", stepId: "crop" },
  { id: "weather", label: "Weather Agent", icon: CloudRain, color: "#38bdf8", stepId: "weather" },
  { id: "disease", label: "Disease Agent", icon: Bug, color: "#fb923c", stepId: "disease" },
  { id: "market", label: "Market Agent", icon: TrendingUp, color: "#a78bfa", stepId: "market" },
];

type StepStatus = "pending" | "active" | "done";

export default function AnalysisPage() {
  const router = useRouter();
  const [steps, setSteps] = useState<Record<string, StepStatus>>(
    AGENT_ANALYSIS_STEPS.reduce((acc, s) => ({ ...acc, [s.id]: "pending" as StepStatus }), {})
  );
  const [currentStep, setCurrentStep] = useState(0);
  const [complete, setComplete] = useState(false);
  const [farmSummary, setFarmSummary] = useState({ crop: "Tomato", location: "Jaipur, Rajasthan" });

  useEffect(() => {
    try {
      const stored = sessionStorage.getItem("agrimind_farm_data");
      if (stored) {
        const data = JSON.parse(stored);
        setFarmSummary({
          crop: data.crop || "Tomato",
          location: data.location || "Jaipur, Rajasthan",
        });
      }
    } catch {}
  }, []);

  useEffect(() => {
    let cancelled = false;

    const runSteps = async () => {
      for (let i = 0; i < AGENT_ANALYSIS_STEPS.length; i++) {
        if (cancelled) return;
        const step = AGENT_ANALYSIS_STEPS[i];

        setCurrentStep(i);
        setSteps((prev) => ({ ...prev, [step.id]: "active" }));

        await new Promise((resolve) => setTimeout(resolve, step.duration));

        if (cancelled) return;
        setSteps((prev) => ({ ...prev, [step.id]: "done" }));
      }
      if (!cancelled) {
        setComplete(true);
        setTimeout(() => {
          if (!cancelled) router.push("/results");
        }, 1200);
      }
    };

    runSteps();
    return () => { cancelled = true; };
  }, [router]);

  const activeAgents = AGENTS.filter((a) => steps[a.stepId] === "active" || steps[a.stepId] === "done");
  const graniteActive = steps["granite"] === "active" || steps["granite"] === "done";

  return (
    <div className="min-h-screen flex items-center justify-center px-4 pt-20">
      {/* Background */}
      <div className="fixed inset-0 bg-hero-mesh opacity-60 pointer-events-none" />
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {[
          [12,15],[45,80],[72,25],[33,60],[88,42],[55,10],[20,70],[65,55],[40,30],[80,85],
          [10,50],[90,15],[25,90],[70,40],[50,65],[15,35],[85,75],[35,20],[60,95],[5,45]
        ].map(([px, py], i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-forest-500"
            initial={{ x: `${px}%`, y: `${py}%`, opacity: 0 }}
            animate={{
              y: [`${py}%`, `${Math.max(0, py - 30)}%`],
              opacity: [0, 0.6, 0],
            }}
            transition={{
              duration: 3 + (i % 4),
              repeat: Infinity,
              delay: (i * 0.3) % 3,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      <div className="relative w-full max-w-2xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="rounded-3xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/80 to-[#071a0e]/80 p-8 md:p-10"
        >
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              animate={{ rotate: complete ? 0 : 360 }}
              transition={{ duration: 2, repeat: complete ? 0 : Infinity, ease: "linear" }}
              className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-forest-600 to-emerald-600 flex items-center justify-center"
            >
              {complete ? (
                <CheckCircle2 className="w-8 h-8 text-white" />
              ) : (
                <Brain className="w-8 h-8 text-white" />
              )}
            </motion.div>
            <AnimatePresence mode="wait">
              <motion.h2
                key={complete ? "done" : "analyzing"}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-2xl font-bold text-white"
              >
                {complete ? "Analysis Complete!" : "AgriMind AI is analyzing your farm..."}
              </motion.h2>
            </AnimatePresence>
            <p className="text-gray-400 text-sm mt-1">
              {farmSummary.crop} • {farmSummary.location}
            </p>
          </div>

          {/* Agent visualization */}
          <div className="relative mb-8">
            {/* SVG connections */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 300 120">
              {AGENTS.map((agent, i) => {
                const x = 40 + i * 73;
                const isActive = steps[agent.stepId] === "active" || steps[agent.stepId] === "done";
                return (
                  <g key={agent.id}>
                    <line
                      x1="150" y1="20"
                      x2={x} y2="90"
                      stroke={isActive ? agent.color : "rgba(255,255,255,0.05)"}
                      strokeWidth={isActive ? "1.5" : "0.5"}
                      strokeDasharray={isActive ? "4 3" : "none"}
                      style={{ transition: "all 0.5s ease" }}
                    />
                    {isActive && (
                      <circle r="3" fill={agent.color}>
                        <animateMotion
                          dur="1.5s"
                          repeatCount="indefinite"
                          path={`M 150 20 L ${x} 90`}
                        />
                      </circle>
                    )}
                  </g>
                );
              })}
            </svg>

            {/* IBM Granite (center top) */}
            <div className="flex justify-center mb-6">
              <motion.div
                animate={graniteActive ? { scale: [1, 1.05, 1] } : {}}
                transition={{ duration: 1.5, repeat: Infinity }}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border transition-all ${
                  graniteActive
                    ? "border-blue-500/60 bg-blue-500/20 shadow-lg shadow-blue-500/20"
                    : "border-blue-900/40 bg-blue-900/10"
                }`}
              >
                <Brain className="w-5 h-5 text-blue-400" />
                <span className={`text-sm font-semibold ${graniteActive ? "text-blue-300" : "text-blue-800"}`}>
                  IBM Granite
                </span>
                {graniteActive && (
                  <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                )}
              </motion.div>
            </div>

            {/* Agent nodes */}
            <div className="grid grid-cols-4 gap-3">
              {AGENTS.map((agent) => {
                const Icon = agent.icon;
                const status = steps[agent.stepId];
                const isActive = status === "active";
                const isDone = status === "done";
                return (
                  <motion.div
                    key={agent.id}
                    animate={isActive ? { scale: [1, 1.06, 1] } : {}}
                    transition={{ duration: 1, repeat: Infinity }}
                    className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                      isDone
                        ? "border-green-700/50 bg-green-900/20"
                        : isActive
                        ? "border-opacity-60 bg-opacity-20"
                        : "border-gray-800/50 bg-gray-900/20"
                    }`}
                    style={
                      isActive
                        ? {
                            borderColor: `${agent.color}80`,
                            backgroundColor: `${agent.color}10`,
                            boxShadow: `0 0 20px ${agent.color}20`,
                          }
                        : {}
                    }
                  >
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center transition-all"
                      style={{
                        background: isDone || isActive ? `${agent.color}25` : "rgba(255,255,255,0.03)",
                      }}
                    >
                      <Icon
                        className="w-4 h-4 transition-colors"
                        style={{ color: isDone || isActive ? agent.color : "#374151" }}
                      />
                    </div>
                    <span className="text-[10px] font-medium text-center leading-tight" style={{ color: isDone || isActive ? agent.color : "#4b5563" }}>
                      {agent.label}
                    </span>
                    {isDone && <span className="text-[10px] text-green-500">✓</span>}
                    {isActive && <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: agent.color }} />}
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Step list */}
          <div className="space-y-2">
            {AGENT_ANALYSIS_STEPS.map((step, i) => {
              const status = steps[step.id];
              const isActive = status === "active";
              const isDone = status === "done";
              return (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{
                    opacity: isDone || isActive ? 1 : 0.3,
                    x: 0,
                  }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center gap-3"
                >
                  {isDone ? (
                    <CheckCircle2 className="w-4 h-4 text-forest-500 flex-shrink-0" />
                  ) : isActive ? (
                    <motion.div
                      animate={{ scale: [1, 1.3, 1], opacity: [0.7, 1, 0.7] }}
                      transition={{ duration: 1, repeat: Infinity }}
                      className="w-4 h-4 rounded-full border-2 border-forest-500 flex-shrink-0"
                    />
                  ) : (
                    <Circle className="w-4 h-4 text-gray-700 flex-shrink-0" />
                  )}
                  <span
                    className={`text-sm ${isDone ? "text-forest-400" : isActive ? "text-white font-medium" : "text-gray-600"}`}
                  >
                    {step.label}
                  </span>
                  {isActive && (
                    <span className="ml-auto flex gap-0.5">
                      {[0, 1, 2].map((d) => (
                        <motion.span
                          key={d}
                          className="w-1 h-1 rounded-full bg-forest-500"
                          animate={{ opacity: [0, 1, 0] }}
                          transition={{ duration: 0.8, repeat: Infinity, delay: d * 0.2 }}
                        />
                      ))}
                    </span>
                  )}
                </motion.div>
              );
            })}
          </div>

          {complete && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 text-center text-forest-400 text-sm font-medium"
            >
              Preparing your intelligence report... ✨
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
