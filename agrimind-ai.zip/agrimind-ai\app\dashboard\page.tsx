"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import {
  Sprout, Droplets, Bug, CloudRain, TrendingUp, Brain, Zap, Calendar, ArrowRight
} from "lucide-react";
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip
} from "recharts";
import { ScoreGauge, StatusBadge, DemoBadge } from "@/components/ui/SharedComponents";
import { DEMO_ANALYSIS_RESULT, DEMO_MARKET, DEMO_WEATHER } from "@/lib/demo/demoData";

const radarData = [
  { subject: "Crop Health", value: 74 },
  { subject: "Irrigation", value: 82 },
  { subject: "Disease Risk", value: 58 },
  { subject: "Soil Health", value: 78 },
  { subject: "Market", value: 70 },
  { subject: "Nutrient", value: 60 },
];

export default function DashboardPage() {
  const result = DEMO_ANALYSIS_RESULT;

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="fixed inset-0 bg-hero-mesh opacity-30 pointer-events-none" />

      <div className="relative max-w-6xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h1 className="text-3xl font-bold text-white">Farm Dashboard</h1>
              <DemoBadge />
            </div>
            <p className="text-gray-400 text-sm">
              📍 Jaipur, Rajasthan · 🌱 Tomato · 2 acres · Last updated: Just now
            </p>
          </div>
          <Link
            href="/analyze"
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-forest-600 hover:bg-forest-500 text-white text-sm font-medium transition-colors"
          >
            <Zap className="w-4 h-4" />
            New Analysis
          </Link>
        </motion.div>

        {/* Top score row */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
          {[
            { icon: "🌱", label: "Crop Health", score: 74, isScore: true },
            { icon: "💧", label: "Water Status", value: "Moderate Stress", isScore: false },
            { icon: "🐛", label: "Disease Risk", value: "Medium", isScore: false },
            { icon: "🌦", label: "Weather Risk", value: "Low-Medium", isScore: false },
            { icon: "💰", label: "Market", value: "Good", isScore: false },
          ].map((card, i) => (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07 }}
              className="rounded-xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/70 to-[#071a0e]/70 p-4 text-center"
            >
              <div className="text-xl mb-2">{card.icon}</div>
              {card.isScore ? (
                <ScoreGauge score={card.score!} label={card.label} size={64} />
              ) : (
                <div>
                  <StatusBadge status={card.value!} />
                  <div className="text-xs text-gray-500 mt-1.5">{card.label}</div>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Main grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Radar chart */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-6"
          >
            <h3 className="font-bold text-white mb-4">Farm Health Overview</h3>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(255,255,255,0.06)" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: "#6b7280", fontSize: 11 }} />
                <Radar name="Farm" dataKey="value" stroke="#22c55e" fill="#22c55e" fillOpacity={0.2} />
              </RadarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* AI Recommendation */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="rounded-2xl border border-blue-800/30 bg-gradient-to-br from-blue-900/15 to-blue-950/20 p-6 lg:col-span-2"
          >
            <div className="flex items-center gap-2 mb-3">
              <Brain className="w-5 h-5 text-blue-400" />
              <h3 className="font-bold text-white">Top AI Recommendation</h3>
              <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/20">IBM Granite</span>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed mb-4">{result.graniteSynthesis.summary}</p>
            <div className="flex flex-wrap gap-2">
              <span className="text-xs px-2 py-1 rounded border border-orange-500/30 bg-orange-500/10 text-orange-400">
                Risk: {result.graniteSynthesis.riskLevel}
              </span>
              <span className="text-xs px-2 py-1 rounded border border-yellow-500/30 bg-yellow-500/10 text-yellow-400">
                {result.graniteSynthesis.urgency}
              </span>
            </div>
            <Link href="/results" className="mt-4 flex items-center gap-1 text-forest-400 hover:text-forest-300 text-sm font-medium transition-colors">
              View Full Report <ArrowRight className="w-4 h-4" />
            </Link>
          </motion.div>
        </div>

        {/* Bottom grid: weather + 7-day plan */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Weather mini */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="rounded-2xl border border-sky-900/40 bg-gradient-to-br from-sky-950/30 to-[#071a0e]/70 p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <CloudRain className="w-4 h-4 text-sky-400" />
                Weather Today
              </h3>
              <DemoBadge />
            </div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-400">{DEMO_WEATHER.current.temp}°C</div>
                <div className="text-xs text-gray-500">Temperature</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-sky-400">{DEMO_WEATHER.current.humidity}%</div>
                <div className="text-xs text-gray-500">Humidity</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">{DEMO_WEATHER.current.rainProb}%</div>
                <div className="text-xs text-gray-500">Rain Prob.</div>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-sky-900/20 border border-sky-800/30 text-xs text-sky-300">
              💧 {DEMO_WEATHER.irrigation.recommendation}
            </div>
            <Link href="/weather" className="mt-3 flex items-center gap-1 text-sky-500 hover:text-sky-400 text-xs font-medium transition-colors">
              Full weather report <ArrowRight className="w-3 h-3" />
            </Link>
          </motion.div>

          {/* Today's action */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="rounded-2xl border border-forest-900/60 bg-gradient-to-br from-[#0d2918]/60 to-[#071a0e]/70 p-6"
          >
            <h3 className="font-bold text-white text-sm flex items-center gap-2 mb-4">
              <Calendar className="w-4 h-4 text-forest-400" />
              Today&#39;s Priority Actions
            </h3>
            <div className="space-y-3">
              {result.actionPlan.slice(0, 3).map((item) => (
                <div key={item.day} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-lg bg-forest-900/60 border border-forest-800/50 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">
                    {item.day}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white">{item.title}</div>
                    <div className="text-xs text-gray-500 mt-0.5">{item.description}</div>
                  </div>
                </div>
              ))}
            </div>
            <Link href="/results" className="mt-4 flex items-center gap-1 text-forest-400 hover:text-forest-300 text-xs font-medium transition-colors">
              View 7-day plan <ArrowRight className="w-3 h-3" />
            </Link>
          </motion.div>
        </div>

        {/* Quick navigation */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { href: "/weather", icon: CloudRain, label: "Weather", color: "text-sky-400", border: "border-sky-800/30", bg: "bg-sky-900/15" },
            { href: "/disease", icon: Bug, label: "Disease Check", color: "text-orange-400", border: "border-orange-800/30", bg: "bg-orange-900/15" },
            { href: "/market", icon: TrendingUp, label: "Market", color: "text-purple-400", border: "border-purple-800/30", bg: "bg-purple-900/15" },
            { href: "/advisor", icon: Brain, label: "AI Advisor", color: "text-blue-400", border: "border-blue-800/30", bg: "bg-blue-900/15" },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 p-4 rounded-xl border ${item.border} ${item.bg} hover:opacity-80 transition-opacity`}
              >
                <Icon className={`w-5 h-5 ${item.color}`} />
                <span className={`text-sm font-medium ${item.color}`}>{item.label}</span>
                <ArrowRight className="w-4 h-4 text-gray-600 ml-auto" />
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
