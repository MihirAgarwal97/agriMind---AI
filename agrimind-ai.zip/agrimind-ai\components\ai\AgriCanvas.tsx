"use client";

import { useEffect, useRef } from "react";

// Animated agricultural scene using Canvas
export default function AgriCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0.5, y: 0.5 });
  const frameRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = canvas.width = canvas.offsetWidth;
    let h = canvas.height = canvas.offsetHeight;

    const resize = () => {
      w = canvas.width = canvas.offsetWidth;
      h = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener("resize", resize);

    const handleMouse = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: (e.clientX - rect.left) / rect.width,
        y: (e.clientY - rect.top) / rect.height,
      };
    };
    window.addEventListener("mousemove", handleMouse);

    // Particles / data points
    const particles: Array<{
      x: number; y: number; vx: number; vy: number;
      r: number; color: string; opacity: number; life: number; maxLife: number;
    }> = [];

    for (let i = 0; i < 60; i++) {
      particles.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.4,
        vy: -Math.random() * 0.6 - 0.2,
        r: Math.random() * 3 + 1,
        color: ["#22c55e", "#10b981", "#16a34a", "#4ade80", "#86efac"][Math.floor(Math.random() * 5)],
        opacity: Math.random() * 0.8 + 0.2,
        life: Math.random() * 200,
        maxLife: 200 + Math.random() * 100,
      });
    }

    // Agent nodes
    const agents = [
      { label: "Crop Agent", color: "#22c55e", angle: -0.8 },
      { label: "Weather Agent", color: "#38bdf8", angle: -0.2 },
      { label: "Disease Agent", color: "#fb923c", angle: 0.4 },
      { label: "Market Agent", color: "#a78bfa", angle: 1.0 },
    ];

    let t = 0;

    const draw = () => {
      ctx.clearRect(0, 0, w, h);

      t += 0.008;
      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      // Background glow
      const grd = ctx.createRadialGradient(w * 0.6, h * 0.4, 0, w * 0.6, h * 0.4, w * 0.6);
      grd.addColorStop(0, "rgba(34,197,94,0.06)");
      grd.addColorStop(1, "transparent");
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, w, h);

      // Draw crop rows (stylized)
      const rowCount = 8;
      for (let i = 0; i < rowCount; i++) {
        const rowY = h * 0.55 + (i * h * 0.07);
        const alpha = Math.max(0, 0.15 - i * 0.018);
        ctx.beginPath();
        ctx.strokeStyle = `rgba(34,197,94,${alpha})`;
        ctx.lineWidth = 1;

        // Perspective effect
        const vanishX = w * (0.5 + mx * 0.1 - 0.05);
        ctx.moveTo(vanishX, h * 0.45);
        ctx.lineTo(w * (i / rowCount) * 0.3 + mx * 10, h);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(vanishX, h * 0.45);
        ctx.lineTo(w - (w * (i / rowCount) * 0.3) - mx * 10, h);
        ctx.stroke();
      }

      // Horizon line glow
      const horizon = h * (0.48 + my * 0.05 - 0.025);
      const horizGrd = ctx.createLinearGradient(0, horizon - 20, 0, horizon + 20);
      horizGrd.addColorStop(0, "transparent");
      horizGrd.addColorStop(0.5, "rgba(34,197,94,0.15)");
      horizGrd.addColorStop(1, "transparent");
      ctx.fillStyle = horizGrd;
      ctx.fillRect(0, horizon - 20, w, 40);

      // Central orchestrator node
      const cx = w * (0.55 + mx * 0.02 - 0.01);
      const cy = h * (0.35 + my * 0.04 - 0.02);
      const pulse = Math.sin(t * 2) * 0.3 + 0.7;

      // Outer glow rings
      for (let r = 3; r >= 1; r--) {
        ctx.beginPath();
        ctx.arc(cx, cy, 28 + r * 12 + pulse * 5, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(34,197,94,${0.06 * (4 - r) * pulse})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // Core node
      const coreGrd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 26);
      coreGrd.addColorStop(0, "rgba(34,197,94,0.9)");
      coreGrd.addColorStop(1, "rgba(16,185,129,0.4)");
      ctx.beginPath();
      ctx.arc(cx, cy, 26, 0, Math.PI * 2);
      ctx.fillStyle = coreGrd;
      ctx.fill();
      ctx.strokeStyle = "rgba(134,239,172,0.6)";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // IBM text
      ctx.fillStyle = "#fff";
      ctx.font = "bold 7px Inter, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("IBM", cx, cy - 3);
      ctx.fillText("Granite", cx, cy + 7);

      // Agent nodes around the center
      agents.forEach((agent, i) => {
        const angle = agent.angle + t * 0.15;
        const dist = 110 + Math.sin(t + i) * 8;
        const ax = cx + Math.cos(angle) * dist + mx * 15 - 7.5;
        const ay = cy + Math.sin(angle * 0.6) * dist * 0.5;

        // Connection line with animated particles
        const lineAlpha = 0.15 + Math.sin(t * 2 + i) * 0.1;
        ctx.beginPath();
        ctx.strokeStyle = `${agent.color}${Math.floor(lineAlpha * 255).toString(16).padStart(2, "0")}`;
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);
        ctx.lineDashOffset = -t * 20;
        ctx.moveTo(cx, cy);
        ctx.lineTo(ax, ay);
        ctx.stroke();
        ctx.setLineDash([]);

        // Data particle along line
        const progress = (t * 0.5 + i * 0.25) % 1;
        const px = cx + (ax - cx) * progress;
        const py = cy + (ay - cy) * progress;
        ctx.beginPath();
        ctx.arc(px, py, 3, 0, Math.PI * 2);
        ctx.fillStyle = agent.color;
        ctx.globalAlpha = 0.9;
        ctx.fill();
        ctx.globalAlpha = 1;

        // Agent node
        const agentPulse = Math.sin(t * 3 + i * 0.8) * 0.2 + 0.8;
        const agrd = ctx.createRadialGradient(ax, ay, 0, ax, ay, 18);
        agrd.addColorStop(0, agent.color + "cc");
        agrd.addColorStop(1, agent.color + "33");
        ctx.beginPath();
        ctx.arc(ax, ay, 18 * agentPulse, 0, Math.PI * 2);
        ctx.fillStyle = agrd;
        ctx.fill();
        ctx.strokeStyle = agent.color + "80";
        ctx.lineWidth = 1;
        ctx.stroke();

        // Label
        ctx.fillStyle = "rgba(255,255,255,0.85)";
        ctx.font = "10px Inter, sans-serif";
        ctx.textAlign = "center";
        const labelY = ay > cy ? ay + 32 : ay - 22;
        ctx.fillText(agent.label, ax, labelY);
      });

      // Floating particles
      particles.forEach((p, i) => {
        p.x += p.vx + Math.sin(t + i) * 0.1;
        p.y += p.vy;
        p.life += 1;

        if (p.life > p.maxLife || p.y < -20) {
          p.x = Math.random() * w;
          p.y = h * 0.6 + Math.random() * h * 0.4;
          p.life = 0;
          p.vy = -Math.random() * 0.6 - 0.2;
        }

        const alpha = p.opacity * (1 - p.life / p.maxLife);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha;
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      // Data readout floating UI elements
      const dataPoints = [
        { label: "Crop Health", value: "82%", x: w * 0.82, y: h * 0.22, color: "#22c55e" },
        { label: "Rain: 15%", value: "🌤", x: w * 0.78, y: h * 0.42, color: "#38bdf8" },
        { label: "Disease Risk", value: "Med", x: w * 0.85, y: h * 0.62, color: "#fb923c" },
      ];

      dataPoints.forEach((dp, i) => {
        const floatY = dp.y + Math.sin(t + i * 1.5) * 8;
        const alpha = 0.7 + Math.sin(t + i) * 0.15;

        ctx.globalAlpha = alpha;
        ctx.fillStyle = "rgba(3,11,6,0.8)";
        ctx.roundRect(dp.x - 40, floatY - 14, 80, 28, 6);
        ctx.fill();
        ctx.strokeStyle = dp.color + "44";
        ctx.lineWidth = 1;
        ctx.roundRect(dp.x - 40, floatY - 14, 80, 28, 6);
        ctx.stroke();

        ctx.fillStyle = dp.color;
        ctx.font = "bold 9px Inter, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(dp.label, dp.x, floatY - 1);

        ctx.fillStyle = "#fff";
        ctx.font = "8px Inter, sans-serif";
        ctx.fillText(dp.value, dp.x, floatY + 10);
        ctx.globalAlpha = 1;
      });

      frameRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(frameRef.current);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", handleMouse);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ display: "block" }}
      aria-label="AgriMind AI - animated agricultural intelligence visualization"
    />
  );
}
